﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WCFDebugging
{
    using WCFDebugging.CurrencyService;

    class Program
    {
        static void Main(string[] args)
        {
            var client = new CurrencyService.CurrencyConvertorSoapClient();
            var rate = client.ConversionRate(Currency.USD, Currency.SEK);

            Console.Write("Enter amount in USD: ");
            var amount = int.Parse(Console.ReadLine());

            var converted = amount * rate;
            Console.WriteLine("In SEK: {0:.00}", converted);
            Console.WriteLine("PRESS ENTER TO EXIT");
            Console.ReadLine();
        }
    }
}
