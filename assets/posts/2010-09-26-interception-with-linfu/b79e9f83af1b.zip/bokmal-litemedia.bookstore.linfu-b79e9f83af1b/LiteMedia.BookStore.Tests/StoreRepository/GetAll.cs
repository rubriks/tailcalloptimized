﻿using LiteMedia.BookStore.Lib;
using NUnit.Framework;

namespace LiteMedia.BookStore.Tests.BookRepositoryTest
{
    [TestFixture]
    public class GetAll
    {
        [Test]
        public void ShouldGetFourBooksFromXmlSource()
        {
            /* Setup */
            var repository = new Lib.StoreRepository();
            
            /* Test */
            var result = repository.GetAll();

            /* Assert */
            Assert.That(result.Count, Is.EqualTo(4));
        }

        [Test]
        public void ShouldApplyProxyThatLazyLoadAuthors()
        {
            /* Setup */
            var repository = new Lib.StoreRepository(new ProxyBuilder(new[] { new LazyLoadAuthorsInterceptor(new Lib.StoreRepository()) }));

            /* Test */
            var result = repository.GetAll();

            /* Assert */
            Assert.That(result[0].Authors.Count, Is.AtLeast(1));
        }

        [Test]
        public void ShouldNotLazyLoadAuthorsOnNonLazyBooks()
        {
            /* Setup */
            var repository = new Lib.StoreRepository();

            /* Test */
            var result = repository.GetAll();

            /* Assert */
            Assert.That(result[0].Authors.Count, Is.EqualTo(0));
        }
    }
}
