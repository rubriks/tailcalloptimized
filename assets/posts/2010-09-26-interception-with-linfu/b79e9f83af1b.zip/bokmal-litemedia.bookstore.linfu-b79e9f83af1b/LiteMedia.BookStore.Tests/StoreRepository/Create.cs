﻿using LiteMedia.BookStore.Lib;
using Microsoft.Practices.Unity;
using NUnit.Framework;

namespace LiteMedia.BookStore.Tests.BookRepository
{
    [TestFixture]
    public class Create
    {
        [Test]
        public void ShouldResolveIBookRepositoryFromContainer()
        {
            /* Setup */
            var container = new Container();

            /* Test */
            var result = container.Resolve<IBookRepository>();

            /* Assert */
            Assert.That(result, Is.AssignableTo<IBookRepository>());
            Assert.That(result, Is.Not.Null);
        }

        [Test]
        public void ShouldResolveIAuthorRepositoryFromContainer()
        {
            /* Setup */
            var container = new Container();

            /* Test */
            var result = container.Resolve<IAuthorRepository>("NoProxyBuilder");

            /* Assert */
            Assert.That(result, Is.AssignableTo<IAuthorRepository>());
            Assert.That(result, Is.Not.Null);
        }

    }
}
