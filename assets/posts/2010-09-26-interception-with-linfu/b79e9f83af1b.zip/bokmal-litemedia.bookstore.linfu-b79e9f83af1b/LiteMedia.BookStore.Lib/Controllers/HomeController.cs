﻿using System.Web.Mvc;

namespace LiteMedia.BookStore.Lib.Controllers
{
    public class HomeController : Controller
    {
        private readonly IBookRepository bookRepository;

        public HomeController(IBookRepository bookRepository)
        {
            this.bookRepository = bookRepository;
        }

        public virtual ViewResult Index()
        {
            var books = bookRepository.GetAll();
            return View(books);
        }
    }
}
