﻿using Castle.Core.Interceptor;
using Castle.DynamicProxy;

namespace LiteMedia.BookStore.Lib
{
    public class ProxyBuilder : IProxyBuilder
    {
        private readonly IInterceptor[] interceptors;
        private readonly ProxyGenerator proxyGenerator;

        public ProxyBuilder(IInterceptor[] interceptors)
            : this(interceptors, new ProxyGenerator())
        {
        }

        public ProxyBuilder(IInterceptor[] interceptors, ProxyGenerator proxyGenerator)
        {
            this.interceptors = interceptors;
            this.proxyGenerator = proxyGenerator;
        }

        public virtual T ProxyFromClass<T>() where T : class
        {
            return proxyGenerator.CreateClassProxy<T>(interceptors);
        }
    }
}
