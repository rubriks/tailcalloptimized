﻿using System.Diagnostics;
using System.Web.Mvc;
using LinFu.IoC;

namespace LiteMedia.BookStore.Lib.Web
{
    public class LinFuControllerFactory : DefaultControllerFactory
    {
        public override IController CreateController(System.Web.Routing.RequestContext requestContext, string controllerName)
        {
            try
            {
                var container = new ControllerContainer();
                return container.GetService<IController>(controllerName);
            }
            catch (NamedServiceNotFoundException)
            {
                Debug.WriteLine("Did not find controller named {0}", new [] { controllerName });
                return null;
            }
        }
    }
}
