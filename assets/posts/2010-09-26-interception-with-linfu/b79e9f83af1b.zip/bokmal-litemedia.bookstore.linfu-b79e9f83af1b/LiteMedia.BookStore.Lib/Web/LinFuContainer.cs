﻿using System.Web.Mvc;
using LinFu.IoC;
using LiteMedia.BookStore.Lib.Controllers;

namespace LiteMedia.BookStore.Lib.Web
{
    public class LinFuContainer : ServiceContainer
    {
        public LinFuContainer()
        {
            this.AddService("Home", typeof(IController), typeof(HomeController));
        }
    }
}
