﻿using System.Web.Mvc;
using LinFu.IoC;
using LinFu.Proxy;
using LinFu.Proxy.Interfaces;
using LiteMedia.BookStore.Lib.Controllers;

namespace LiteMedia.BookStore.Lib.Web
{
    public class ControllerContainer : ServiceContainer
    {
        public ControllerContainer()
        {
            var factory = new ProxyFactory();
            var repository = new StoreRepository();
            var coverLocalizer = new CoverLocalizer(repository);

            this.AddService<IController>("Home", () => new HomeController(
                factory.CreateProxy<IBookRepository>(coverLocalizer)));
        }
    }
}
