﻿using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Web;
using LinFu.AOP.Interfaces;
using LiteMedia.BookStore.Lib.Model;

namespace LiteMedia.BookStore.Lib.Web
{
    public class CoverLocalizer : IInvokeWrapper
    {
        private readonly IBookRepository target;

        public CoverLocalizer(IBookRepository target)
        {
            this.target = target;
        }

        public void BeforeInvoke(IInvocationInfo info)
        {
            Debug.WriteLine("Before {0}", new[] { info.TargetMethod.Name });
        }

        public void AfterInvoke(IInvocationInfo info, object returnValue)
        {
            Debug.WriteLine("After {0}", new[] { info.TargetMethod.Name });

            foreach (var book in (IEnumerable<Book>)returnValue)
            {
                var imagePath = "/Images/" + book.Isbn;
                var localImagePath = HttpContext.Current.Server.MapPath(imagePath);

                if (File.Exists(localImagePath))
                {
                    book.Cover = imagePath;
                    continue;
                }

                var request = (HttpWebRequest) WebRequest.Create(book.Cover);
                using (var fileStream = new FileStream(localImagePath, FileMode.Create))
                {
                    CopyStream(request.GetResponse().GetResponseStream(), fileStream);
                }

                book.Cover = imagePath;
            }
        }

        public object DoInvoke(IInvocationInfo info)
        {
            Debug.WriteLine("Invoking {0}", new[] { info.TargetMethod.Name });
            return info.TargetMethod.Invoke(target, info.Arguments);
        }

        private static void CopyStream(Stream input, Stream output)
        {
            byte[] buffer = new byte[32768];
            while (true)
            {
                int read = input.Read(buffer, 0, buffer.Length);
                if (read <= 0)
                    return;
                output.Write(buffer, 0, read);
            }
        }
    }
}
