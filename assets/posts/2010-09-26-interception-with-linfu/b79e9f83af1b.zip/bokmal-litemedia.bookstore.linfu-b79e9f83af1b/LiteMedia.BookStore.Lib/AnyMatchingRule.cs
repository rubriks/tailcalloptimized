﻿using System.Reflection;
using Microsoft.Practices.Unity.InterceptionExtension;

namespace LiteMedia.BookStore.Lib
{
    public class AnyMatchingRule : IMatchingRule
    {
        public bool Matches(MethodBase member)
        {
            return true;
        }
    }
}
