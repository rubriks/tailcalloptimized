﻿using System.Collections.Generic;
using LiteMedia.BookStore.Lib.Model;

namespace LiteMedia.BookStore.Lib
{
    public interface IAuthorRepository
    {
        IList<Author> GetAuthorsForBook(string isbn);
    }
}
