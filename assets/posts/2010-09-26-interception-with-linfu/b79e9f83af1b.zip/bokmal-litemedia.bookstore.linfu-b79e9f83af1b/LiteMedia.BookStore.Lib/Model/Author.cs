﻿namespace LiteMedia.BookStore.Lib.Model
{
    public class Author
    {
        public string Name { get; set; }

        public override string ToString()
        {
            return Name;
        }
    }
}
