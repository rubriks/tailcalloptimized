﻿namespace MintDataAnnotations.Model
{
    using System.ComponentModel.DataAnnotations;

    [MetadataType(typeof(IPerson))]
    public class Person : IPerson
    {
        public string Name { get; set; }

        public int Age { get; set; }

        public string Email { get; set; }
    }
}
