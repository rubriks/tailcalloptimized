﻿namespace MintDataAnnotations.Model
{
    using System.ComponentModel.DataAnnotations;

    public interface IPerson
    {
        [StringLength(20), Required(ErrorMessage = "Name is a required property")]
        string Name { get; set; }

        [Range(0, 150)]
        int Age { get; set; }

        [RegularExpression(@"(?i:^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$)")]
        string Email { get; set; }
    }
}
