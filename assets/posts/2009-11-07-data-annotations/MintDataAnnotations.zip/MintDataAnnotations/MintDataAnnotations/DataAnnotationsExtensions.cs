﻿namespace MintDataAnnotations
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Linq;
    using System.Linq.Expressions;
    using System.Reflection;

    public static class DataAnnotationsExtensions
    {
        /// <summary>
        /// Validates the annotations.
        /// </summary>
        /// <typeparam name="T">Any kind of object with DataAnnotations</typeparam>
        /// <param name="instance">The instance that should be validated</param>
        /// <returns>ValidationMessage that specifies the outcome of the validation</returns>
        /// <exception cref="ArgumentNullException"><c>instance</c> is null.</exception>
        public static ValidationMessage ValidateAnnotations<T>(this T instance)
            where T : class
        {
            if (instance == null)
            {
                throw new ArgumentNullException("instance");
            }

            foreach (var property in typeof(T).GetProperties(BindingFlags.Instance | BindingFlags.Public | BindingFlags.GetField))
            {
                var result = ValidateAnnotations(property, instance);

                if (!result.IsValid)
                {
                    return result;
                }
            }

            return new ValidationMessage { IsValid = true };
        }

        /// <summary>
        /// Validates the annotations for a specific property
        /// </summary>
        /// <typeparam name="T">Any kind of object with DataAnnotations</typeparam>
        /// <param name="instance">The instance that should be validated</param>
        /// <param name="property">The property that we wants to validate</param>
        /// <returns>ValidationMessage that specifies the outcome of the validation</returns>
        /// <exception cref="ArgumentNullException">When <c>instance</c> or <c>property</c> is null.</exception>
        public static ValidationMessage ValidateAnnotations<T>(this T instance, Expression<Func<T, object>> property)
            where T : class
        {
            if (instance == null)
            {
                throw new ArgumentNullException("instance");
            }

            if (property == null)
            {
                throw new ArgumentNullException("property");
            }

            var memberExpression = property.Body as MemberExpression;
            if (memberExpression == null)
            {
                var unaryExpression = (UnaryExpression)property.Body;
                memberExpression = (MemberExpression)unaryExpression.Operand;
            }
            
            return ValidateAnnotations((PropertyInfo)memberExpression.Member, instance);
        }

        private static ValidationMessage ValidateAnnotations(PropertyInfo member, object instance)
        {
            /* When MetadataTypeAttribute is defined, get the DataAnnotations from that class instead */
            var metadataType = member.DeclaringType.GetAttribute<MetadataTypeAttribute>();
            if (metadataType != null)
            {
                return ValidateAnnotations(metadataType.MetadataClassType, member.Name, instance);
            }

            var validationAttributes = member.GetAttributes<ValidationAttribute>();
            foreach (var annotation in validationAttributes)
            {
                if (!annotation.IsValid(member.GetValue(instance, null)))
                {
                    return new ValidationMessage
                    {
                        IsValid = false,
                        ErrorMessage = annotation.ErrorMessage,
                        ErrorMessageResourceName = annotation.ErrorMessageResourceName
                    };
                }
            }

            return new ValidationMessage { IsValid = true };
        }

        /// <summary>
        /// Validates the annotations in a given metadataType
        /// </summary>
        /// <param name="metadataType">Type where the DataAnnotations are defined</param>
        /// <param name="propertyName">Name of the property are to be validated</param>
        /// <param name="instance">The instance data that should be validated</param>
        /// <returns>ValidationMessage that specifies the outcome of the validation</returns>
        /// <exception cref="ArgumentException">When propertyName does not match a property in metadataType</exception>
        private static ValidationMessage ValidateAnnotations(Type metadataType, string propertyName, object instance)
        {
            var property = metadataType.GetProperty(propertyName);

            if (property == null)
            {
                throw new ArgumentException("Could not find matching property " + propertyName + " in MetaDataType", "propertyName");
            }

            return ValidateAnnotations(property, instance);
        }

        private static TAttribute GetAttribute<TAttribute>(this ICustomAttributeProvider cap)
            where TAttribute : Attribute
        {
            return cap.GetCustomAttributes(typeof(TAttribute), true)
                .Cast<TAttribute>()
                .FirstOrDefault();
        }

        private static IEnumerable<TAttribute> GetAttributes<TAttribute>(this ICustomAttributeProvider member)
            where TAttribute : Attribute
        {
            return member.GetCustomAttributes(true)
                .Where(attribute => typeof(TAttribute).IsAssignableFrom(attribute.GetType()))
                .Cast<TAttribute>();
        }
    }
}
