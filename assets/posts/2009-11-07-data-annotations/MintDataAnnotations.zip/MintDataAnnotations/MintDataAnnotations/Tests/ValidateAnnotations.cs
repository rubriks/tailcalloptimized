﻿using System;
using Rhino.Mocks;

namespace MintDataAnnotations.Tests
{
    using Model;
    using NUnit.Framework;

    [TestFixture]
    public class ValidateAnnotations
    {
        [Test(Description = "Run a positive test where data should be valid, and verify that the ValidationMessage.IsValid equals true")]
        public void ShouldReturnIsValidMessageWhenInstanceIsValid()
        {
            /* Setup */
var person = new Person
{
    Name = "John Doe",
    Age = 54,
    Email = "john.doe@aol.com"
};

/* Test */
var result = person.ValidateAnnotations();

            /* Assert */
            Assert.IsTrue(result.IsValid, "Expected the validation result to be IsValid == true");
        }

        [Test(Description = "Decorating property member with attribute Required will return ValidationMessage.IsValid == false when the value is null")]
        public void ShouldReturnInvalidMessageWhenRequiredFieldIsNull()
        {
            /* Setup */
            var person = new Person
            {
                Name = null
            };

            /* Test */
            var result = person.ValidateAnnotations();

            /* Assert */
            Assert.IsFalse(result.IsValid, "Expected ValidationMessage.IsValid == false because Person.Name was not set");
        }

        [Test(Description = "Decorating property member with attribute StringLength requires the property member value to be shorter than the annotated length")]
        public void ShouldReturnInvalidMessageWhenStringValueIsLongerThanAnnotationAllows()
        {
            /* Setup */
            var person = new Person
            {
                Name = "John Evert Baltazar Doe",
                Age = 54
            };

            /* Test */
            var result = person.ValidateAnnotations();

            /* Assert */
            Assert.IsFalse(result.IsValid, "Expected ValidationMessage.IsValid == false because Person.Name was longer than 20 characters");
        }

        [Test(Description = "Decorating property member with attribute RegularExpression requires the property member value to match the given expression")]
        public void ShouldReturnInvalidMessageWhenRegularExpressionDoesNotMatchStringValue()
        {
            /* Setup */
            var person = new Person
            {
                Name = "John Doe",
                Age = 54,
                Email = "http://mint.litemedia.se"
            };

            /* Test */
            var result = person.ValidateAnnotations();

            /* Assert */
            Assert.IsFalse(result.IsValid, "Expected ValidationMessage.IsValid == false because Person.Email was not an e-mail and did not match annotated regular expression");
        }

        [Test(Description = "When validation is invalid the annotation ErrorMessage should be included in the ValidationMessage")]
        public void ShouldIncludeErrorMessageWhenValidationFails()
        {
            /* Setup */
            var person = new Person();

            /* Test */
            var result = person.ValidateAnnotations();

            /* Assert */
            Assert.AreEqual("Name is a required property", result.ErrorMessage);
        }

        [Test]
        public void CannotValidateAnnotationsOnNullInstance()
        {
            /* Setup */
            const Person Person = null;

            /* Test */
            TestDelegate code = () => Person.ValidateAnnotations();

            /* Assert */
            Assert.Throws(typeof(ArgumentNullException), code, "Expected code to throw ArgumentNullException because we're sending in a null value for validation");
        }

        [Test]
        public void ShouldValidateTheSpecifiedProperty()
        {
            /* Setup */
            var person = new Person
            {
                Name = "John Doe"
            };

            /* Test */
            var result = person.ValidateAnnotations(p => p.Name);

            /* Assert */
            Assert.IsTrue(result.IsValid, "Expected ValidationMessage.IsValid to be true");
        }

        [Test]
        public void ShouldOnlyValidateTheSpecifiedPropertyAndNotTouchOtherProperties()
        {
            /* Setup */
            var person = MockRepository.GenerateStrictMock<IPerson>();

            /* Arrange */
            person.Expect(p => p.Age).Return(-2);

            /* Act */
            var result = person.ValidateAnnotations(p => p.Age);

            /* Assert */
            Assert.IsFalse(result.IsValid, "Did not expect the validation to be valid");
        }
    }
}
