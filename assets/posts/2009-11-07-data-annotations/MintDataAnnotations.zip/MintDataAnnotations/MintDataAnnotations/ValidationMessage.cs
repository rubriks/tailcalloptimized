﻿namespace MintDataAnnotations
{
    public class ValidationMessage
    {
        public bool IsValid { get; set; }

        public string ErrorMessage { get; set; }

        public string ErrorMessageResourceName { get; set; }
    }
}
