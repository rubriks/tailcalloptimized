﻿namespace ValidateXHtmlStrict
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Net;
    using System.Reflection;
    using System.Text;
    using System.Xml;
    using System.Xml.Linq;
    using System.Xml.Schema;
    using NUnit.Framework;

    [TestFixture]
    public class ValidateXHtmlStrict
    {
        private const string ValidationSchema = "xhtml1-strict.xsd";
        private static readonly string GoogleSiteMapUrl = "http://www.vardguiden.se/SiteMap.xml?SiteMap_0.xml";

        [Test]
        public void ShouldValidate()
        {
            /* Setup */
            var urls = GetTargetUrls(GoogleSiteMapUrl);
            bool isValid = true;
            var errorMessage = new StringBuilder();

            /* Test */
            foreach (var url in urls)
            {
                try
                {
                    using (var xsd = GetEmbeddedResource(ValidationSchema))
                    using (var html = GetHtmlContent(url))
                    {
                        // If the html is XHtml Strict, this should be possible
                        var result = new XmlDocument();
                        result.Load(html);
                        
                        using (TextReader schemaReader = new StreamReader(xsd))
                        {
                            var callback = new ValidationEventHandler(ValidationCallBack);
                            var schema = XmlSchema.Read(schemaReader, callback);
                            result.Schemas.Add(schema);

                            result.Validate(callback);
                        }
                    }
                }
                catch (Exception e)
                {
                    isValid = false;
                    errorMessage.AppendFormat("{0}: {1}\n", url, e.Message);
                }
            }

            /* Assert */
            Assert.IsTrue(isValid, errorMessage.ToString());
        }

        private static void ValidationCallBack(object sender, ValidationEventArgs e)
        {
            Assert.Fail(e.Severity + ": " + e.Message);
        }

        private Stream GetHtmlContent(string url)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.UserAgent = "W3C_Validator/1.0 libwww-perl/0.40";
            request.ContentType = "application/x-www-form-urlencoded;charset=\"utf-8\"";
            return request.GetResponse().GetResponseStream();
        }

        private IEnumerable<string> GetTargetUrls(string googleSiteMapUrl)
        {
            XNamespace xmlns = "http://www.sitemaps.org/schemas/sitemap/0.9";
            var document = XDocument.Load(googleSiteMapUrl);
            return from loc in document.Descendants(xmlns + "loc")
                   select loc.Value;
        }

        private Stream GetEmbeddedResource(string relativePath)
        {
            string path = string.Format("{0}.{1}", GetType().Namespace, relativePath);
            return Assembly.GetCallingAssembly().GetManifestResourceStream(path);
        }
    }
}
