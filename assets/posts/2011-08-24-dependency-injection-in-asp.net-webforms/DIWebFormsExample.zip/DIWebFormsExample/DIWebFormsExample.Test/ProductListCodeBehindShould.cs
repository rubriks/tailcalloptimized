﻿using System;
using System.Linq;
using NUnit.Framework;
using Rhino.Mocks;
using System.Collections.Generic;

namespace DIWebFormsExample.Lib.Test
{
    [TestFixture]
    public class ProductListCodeBehindShould
    {
        private class Template : ProductList
        {
            public Template()
            {
                Repository = new StubRepository();
            }

            public new IEnumerable<Product> GetByType(string type)
            {
                return base.GetByType(type);
            }

            private class StubRepository : IRepository<Product>
            {
                public IEnumerable<Product> Get(Func<Product, bool> criteria)
                {
                    return new[]
                    {
                        new Product("Stereo", 120.0, "Electronics"),
                        new Product("Candy bar", 1.2, "Candy"),
                        new Product("Soda", 1.8, "Candy"),
                        new Product("Deep fried snickers bar", 0.2, "Candy")
                    }.Where(criteria);
                }
            }
        }

        [TestCase("Electronics", 120.0)]
        [TestCase("Candy", 3.2)]
        public void GetProductsBySpecifiedType(string type, double totalPrice)
        {
            /* Setup */
            var template = new Template();

            /* Test */
            var products = template.GetByType(type);

            /* Assert */
            Assert.That(products.Sum(p => p.Price), Is.EqualTo(totalPrice));
        }
    }
}
