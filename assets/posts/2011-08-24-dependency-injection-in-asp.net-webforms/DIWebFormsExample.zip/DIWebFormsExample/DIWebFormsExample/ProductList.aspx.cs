﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using DIWebFormsExample.Lib;
using Microsoft.Practices.Unity;

namespace DIWebFormsExample
{
    public partial class ProductList : System.Web.UI.Page
    {
        [Dependency]
        public IRepository<Product> Repository { get; set; }

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected IEnumerable<Product> GetByType(string type)
        {
            return Repository.Get(p => p.Type == type);
        }

        protected void DataBind(object sender, EventArgs e)
        {
            ((Control) sender).DataBind();
        }
    }
}