﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DIWebFormsExample.Lib
{
    public class ProductRepository : IRepository<Product>
    {
        private List<Product> products = new List<Product>
        {
            new Product("Stereo", 120.0, "Electronics"),
            new Product("Candy bar", 1.2, "Candy"),
            new Product("Soda", 1.8, "Candy"),
            new Product("Deep fried snickers bar", 0.2, "Candy")
        };

        public IEnumerable<Product> Get(Func<Product, bool> criteria)
        {
            return products.Where(criteria);
        }
    }
}
