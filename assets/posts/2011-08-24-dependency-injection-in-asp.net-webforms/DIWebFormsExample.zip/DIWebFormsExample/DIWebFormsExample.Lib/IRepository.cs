﻿using System;
using System.Collections.Generic;

namespace DIWebFormsExample.Lib
{
    public interface IRepository<TEntity>
    {
        IEnumerable<TEntity> Get(Func<TEntity, bool> criteria);
    }
}
