﻿namespace DIWebFormsExample.Lib
{
    public class Product
    {
        public Product(string name, double price, string type)
        {
            Name = name;
            Price = price;
            Type = type;
        }

        public string Name { get; private set; }

        public double Price { get; private set; }

        public string Type { get; private set; }
    }
}
