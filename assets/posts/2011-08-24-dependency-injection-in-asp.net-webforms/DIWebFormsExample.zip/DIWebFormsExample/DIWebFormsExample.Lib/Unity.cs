﻿namespace DIWebFormsExample.Lib
{
    using Microsoft.Practices.Unity;

    public class Unity
    {
        private static readonly object PadLock = new object();
        private static Unity _unity;
        private readonly IUnityContainer container;

        private Unity()
        {
            container = new UnityContainer();
            container.RegisterType<IRepository<Product>, ProductRepository>();
        }

        public static Unity Instance
        {
            get { lock (PadLock) { return _unity ?? (_unity = new Unity()); } }
        }

        public IUnityContainer Container
        {
            get { return container; }
        }
    }
}
