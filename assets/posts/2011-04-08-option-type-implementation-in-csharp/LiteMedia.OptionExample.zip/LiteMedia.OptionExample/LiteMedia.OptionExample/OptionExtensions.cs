﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiteMedia.OptionExample
{
    public static class OptionExtensions
    {
        public static Option<T> SomeOrNone<T>(this T reference)
            where T : class
        {
            if (reference == null) return new None<T>();
            return new Some<T>(reference);
        }
    }
}
