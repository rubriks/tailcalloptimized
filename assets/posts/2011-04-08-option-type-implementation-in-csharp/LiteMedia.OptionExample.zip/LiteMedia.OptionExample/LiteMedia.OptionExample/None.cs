﻿namespace LiteMedia.OptionExample
{
    public sealed class None<T> : Option<T>
    {
        public override T Value
        {
            get { throw new System.NotSupportedException("There is no value"); }
        }

        public override bool IsSome { get { return false; } }

        public override bool IsNone { get { return true; } }
    }
}
