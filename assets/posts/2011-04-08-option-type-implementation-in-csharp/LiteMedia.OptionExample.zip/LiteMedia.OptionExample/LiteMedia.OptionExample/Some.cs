﻿namespace LiteMedia.OptionExample
{
    public sealed class Some<T> : Option<T>
    {
        private T value;
        public Some(T value)
        {
            // Setting Some to null, nullifies the purpose of Some/None
            if (value == null)
            {
                throw new System.ArgumentNullException("value", "Some value was null, use None instead");
            }

            this.value = value;
        }

        public override T Value { get { return value; } }

        public override bool IsSome { get { return true; } }

        public override bool IsNone { get { return false; } }
    }
}
