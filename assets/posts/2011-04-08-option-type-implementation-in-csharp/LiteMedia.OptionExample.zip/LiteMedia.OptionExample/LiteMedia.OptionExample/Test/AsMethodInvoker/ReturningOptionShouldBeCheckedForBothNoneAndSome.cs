﻿namespace LiteMedia.OptionExample.Test.AsMethodInvoker
{
    using NUnit.Framework;

    [TestFixture]
    public class ReturningOptionShouldBeCheckedForBothNoneAndSome
    {
        // Get string before substring
        private string SubstringBefore(string s, string substring)
        {
            var operations = new StringOperations();
            var index = operations.GetIndexOfSubstring(s, substring);

            if (index.IsSome) 
                return s.Substring(index.Value);

            return s;
        }

        private class StringOperations : OptionIsUsefulWhenMethodCouldHaveNoResult
        {   
        }
    }
}
