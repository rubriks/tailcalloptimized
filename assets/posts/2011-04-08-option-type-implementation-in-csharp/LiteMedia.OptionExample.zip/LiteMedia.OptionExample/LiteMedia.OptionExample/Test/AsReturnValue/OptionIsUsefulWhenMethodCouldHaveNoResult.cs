﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiteMedia.OptionExample.Test
{
    using NUnit.Framework;

    public class OptionIsUsefulWhenMethodCouldHaveNoResult
    {
        public Option<int> GetIndexOfSubstring(string s, string substring)
        {
            var index = s.IndexOf(substring);
            if (index == -1) return 
                new None<int>();

            return new Some<int>(index);
        }

        [Test]
        public void ShouldReturnSomeIndexForExistingSubstring()
        {
            /* Setup */
            var name = "Mikael Lundin";

            /* Test */
            var result = GetIndexOfSubstring(name, "Lundin");

            /* Assert */
            Assert.That(result is Some<int>);
            Assert.That(result.Value, Is.EqualTo(7));
        }

        [Test]
        public void ShouldReturnNoneWhenSubstringDoesNotExist()
        {
            /* Setup */
            var name = "Mikael Lundin";

            /* Test */
            var result = GetIndexOfSubstring(name, "Monkey");

            /* Assert */
            Assert.That(result is None<int>);
        }
    }
}
