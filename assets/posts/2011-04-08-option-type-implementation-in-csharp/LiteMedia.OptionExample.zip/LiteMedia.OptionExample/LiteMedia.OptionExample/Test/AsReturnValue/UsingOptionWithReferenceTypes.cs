﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace LiteMedia.OptionExample.Test.AsReturnValue
{
    using NUnit.Framework;
    
    [TestFixture]
    public class UsingOptionWithReferenceTypes
    {
        private static IList<User> Users = new List<User>
            { new User("John", "Rogers"), new User("Sitting", "Bull"), new User("Clint", "Eastwood") };
        

        public Option<User> FindUserByName(string name)
        {
            var query = from user in Users
                        where user.FirstName.Contains(name) || user.Surname.Contains(name)
                        select user;

            var found = query.FirstOrDefault();
            return found.SomeOrNone();
        }

        public class User
        {
            public User(string firstName, string surname)
            {
                FirstName = firstName;
                Surname = surname;
            }

            public string FirstName { get; set; }
            public string Surname { get; set; }
        }

        [Test]
        public void ShouldFindAndReturnSomeEastwood()
        {
            /* Test */
            var user = this.FindUserByName("Eastwood");

            /* Assert */
            Assert.That(user is Some<User>);
            Assert.That(user.Value.FirstName, Is.EqualTo("Clint"));
        }

        [Test]
        public void ShouldFindNonePoppins()
        {
            /* Test */
            var user = this.FindUserByName("Poppins");

            /* Assert */
            Assert.That(user is None<User>);
        }
    }


}
