﻿namespace LiteMedia.OptionExample
{
    // Abstract, used as return type from method
    public abstract class Option<T>
    {
        // Could contain the value if Some, but not if None
        public abstract T Value { get; }

        public abstract bool IsSome { get; }

        public abstract bool IsNone { get; }
    }
}
