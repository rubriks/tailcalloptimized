﻿using System;
using System.Configuration;
using LiteMedia.ExampleConfiguration.Configuration;

namespace LiteMedia.ExampleConfiguration
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var configuration = (SectionHandler)ConfigurationManager.GetSection("fileCopy");

            Console.WriteLine("SOURCE DIRECTORIES");
            foreach (Directory directory in configuration.Source)
            {
                Console.WriteLine(directory.Path);
            }

            Console.WriteLine("DESTINATION DIRECTORIES");
            foreach (Directory directory in configuration.Destination)
            {
                Console.WriteLine(directory.Path);
            }

            Console.ReadLine();
        }
    }
}
