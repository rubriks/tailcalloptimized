﻿namespace LiteMedia.ExampleConfiguration.Configuration
{
    using System.Configuration;

    public class Directory : ConfigurationElement
    {
        private const string PathIdentifier = "path";

        [ConfigurationProperty(PathIdentifier)]
        public string Path
        {
            get { return (string)this[PathIdentifier]; }
            set { this[PathIdentifier] = value; }
        }
    }
}
