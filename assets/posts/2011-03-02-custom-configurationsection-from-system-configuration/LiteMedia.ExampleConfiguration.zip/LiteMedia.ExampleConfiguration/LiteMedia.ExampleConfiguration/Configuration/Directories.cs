﻿namespace LiteMedia.ExampleConfiguration.Configuration
{
    using System.Configuration;

    [ConfigurationCollection(typeof(Directory),
        CollectionType = ConfigurationElementCollectionType.BasicMap,
        AddItemName = AddItemNameIdentifier)]
    public class Directories : ConfigurationElementCollection
    {
        public const string AddItemNameIdentifier = "directory";

        public override ConfigurationElementCollectionType CollectionType
        {
            get { return ConfigurationElementCollectionType.BasicMap; }
        }

        protected override string ElementName
        {
            get { return AddItemNameIdentifier; }
        }

        public void Add(Directory directory)
        {
            BaseAdd(directory);
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new Directory();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            var instance = (Directory)element;
            return instance.Path;
        }
    }
}
