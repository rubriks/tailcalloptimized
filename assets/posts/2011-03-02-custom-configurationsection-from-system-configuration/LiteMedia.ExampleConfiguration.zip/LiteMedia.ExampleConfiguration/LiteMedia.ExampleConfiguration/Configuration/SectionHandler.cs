﻿using System.Configuration;

namespace LiteMedia.ExampleConfiguration.Configuration
{
    public class SectionHandler : ConfigurationSection
    {
        private const string SourceIdentifier = "source";
        private const string DestinationIdentifier = "destination";

        [ConfigurationProperty(SourceIdentifier)]
        public Directories Source
        {
            get { return (Directories)this[SourceIdentifier]; }
            set { this[SourceIdentifier] = value; }
        }

        [ConfigurationProperty(DestinationIdentifier)]
        public Directories Destination
        {
            get { return (Directories)this[DestinationIdentifier]; }
            set { this[SourceIdentifier] = value; }
        }
    }
}
