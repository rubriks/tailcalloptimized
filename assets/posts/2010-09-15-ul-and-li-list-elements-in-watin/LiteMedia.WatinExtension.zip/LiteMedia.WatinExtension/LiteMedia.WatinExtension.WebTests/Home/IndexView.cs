﻿using WatiN.Core;

namespace LiteMedia.WatinExtension.WebTests.Home
{
    public class IndexView : Page
    {
        private const string ColorListId = "colors";

        public Ul ColorList
        {
            get { return Document.ElementOfType<Ul>(ColorListId); }
        }
    }
}
