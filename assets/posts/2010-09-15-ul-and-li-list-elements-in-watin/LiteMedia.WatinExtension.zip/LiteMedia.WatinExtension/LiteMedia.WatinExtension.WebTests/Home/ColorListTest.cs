﻿using NUnit.Framework;
using WatiN.Core;
using System.Linq;

namespace LiteMedia.WatinExtension.WebTests.Home
{
    [TestFixture]
    public class ColorListTest
    {
        [Test]
        public void ShouldHaveListWithThreeColors()
        {
            using (var browser = new IE("http://localhost:51562"))
            {
                var index = browser.Page<IndexView>();

                Assert.That(index.ColorList.Items.Count, Is.EqualTo(3));
                Assert.That(index.ColorList.Items[0].Text.Trim(), Is.EqualTo("Blue"));
                Assert.That(index.ColorList.Items[1].Text.Trim(), Is.EqualTo("Green"));
                Assert.That(index.ColorList.Items[2].Text.Trim(), Is.EqualTo("White"));
            }
        }
    }
}
