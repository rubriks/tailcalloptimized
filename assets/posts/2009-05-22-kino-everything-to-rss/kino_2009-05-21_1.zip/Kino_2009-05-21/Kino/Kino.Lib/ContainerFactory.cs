﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ContainerFactory.cs" company="LiteMedia">
//   Use and copy at your own lesiure.
// </copyright>
// <summary>
//   A factory for retrieving Unity containers
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Lib
{
    using System;
    using System.Configuration;
    using Microsoft.Practices.Unity;
    using Microsoft.Practices.Unity.Configuration;

    /// <summary>
    /// A factory for retrieving Unity containers
    /// </summary>
    public class ContainerFactory
    {
        public const string RssDocuments = "rssDocuments";
        private const string UnityConfigurationSection = "unity";

        private static readonly object padlock = new object();
        private static ContainerFactory instance;

        private UnityConfigurationSection configurationSection;

        public ContainerFactory(UnityConfigurationSection configurationSection)
        {
            if (configurationSection == null)
                throw new ArgumentNullException("configurationSection");

            this.configurationSection = configurationSection;
        }

        private ContainerFactory()
            : this((UnityConfigurationSection)ConfigurationManager.GetSection(UnityConfigurationSection))
        {
        }

        /// <summary>
        /// Gets the instance of this singleton
        /// </summary>
        /// <value>The instance.</value>
        public static ContainerFactory Instance
        {
            get
            {
                lock (padlock)
                {
                    if (instance == null)
                    {
                        instance = new ContainerFactory();
                    }

                    return instance;
                }
            }
        }

        /// <summary>
        /// Creates a new container and configure it from the XML configuration.
        /// </summary>
        /// <param name="name">
        /// The name is used to identify the containers XML configuration
        /// </param>
        /// <returns>
        /// </returns>
        public UnityContainer GetContainer(string name)
        {
            if (configurationSection == null)
                throw new InvalidOperationException("No unity configuration was found, could not instansiate container");

            var container = new UnityContainer();

            UnityContainerElement containerConfiguration = configurationSection.Containers[name];
            if (containerConfiguration == null)
                throw new ConfigurationErrorsException("No unity configuration for " + name + " was found");

            containerConfiguration.Configure(container);
            return container;
        }
    }
}