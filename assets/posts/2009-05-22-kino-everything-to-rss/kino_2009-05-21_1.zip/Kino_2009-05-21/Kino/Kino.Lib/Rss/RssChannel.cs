﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssChannel.cs" company="LiteMedia">
//   Use and copy at your own lesiure.
// </copyright>
// <summary>
//   In in memory object representation of the rss channel element
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Lib.Rss
{
    using System;
    using System.Collections.Generic;
    using System.Globalization;
    using System.Xml.Serialization;

    /// <summary>
    /// In in memory object representation of the rss channel element
    /// </summary>
    public class RssChannel
    {
        /// <summary>
        /// The name of the channel. It's how people refer to your service. If you have an HTML website that contains the same information as your RSS file, the title of your channel should be the same as the title of your website.
        /// </summary>
        /// <value>The title of your channel</value>
        [XmlElement(ElementName = "title")]
        public string Title { get; set; }

        /// <summary>
        /// The URL to the HTML website corresponding to the channel.
        /// </summary>
        /// <value>The link to website for this channel</value>
        [XmlElement(ElementName = "link")]
        public string Link { get; set; }

        /// <summary>
        /// Phrase or sentence describing the channel.
        /// </summary>
        /// <value>The description of the contents</value>
        [XmlElement(ElementName = "description")]
        public string Description { get; set; }

        /// <summary>
        /// The language the channel is written in. This allows aggregators to group all Italian language sites, for example, on a single page.
        /// </summary>
        /// <value>The language.</value>
        [XmlElement(ElementName = "language")]
        public string Language { get; set; }

        /// <summary>
        /// The publication date for the content in the channel. For example, the New York Times publishes on a daily basis, the publication date flips once every 24 hours. That's when the pubDate of the channel changes. All date-times in RSS conform to the Date and Time Specification of RFC 822, with the exception that the year may be expressed with two characters or four characters (four preferred).
        /// </summary>
        /// <value>The publication date.</value>
        [XmlIgnore]
        public DateTime PublicationDate { get; set; }

        /// <summary>
        /// Gets or sets the publication date XML serialization output. This is only used 
        /// for XML serialization, since you can't really control output of serialization
        /// of a DateTime object.
        /// </summary>
        /// <value>The publication date XML serialization output.</value>
        [XmlElement(ElementName = "pubDate")]
        public string PublicationDateXmlSerializationOutput
        {
            get
            {
                return PublicationDate.ToString(RssDocument.RSS_DATE_FORMAT, CultureInfo.GetCultureInfo(RssDocument.RSS_DATE_CULTUREINFO));
            }

            set
            {
                PublicationDate = DateTime.Parse(value, CultureInfo.GetCultureInfo(RssDocument.RSS_DATE_CULTUREINFO));
            }
        }

        /// <summary>
        /// The last time the content of the channel changed.
        /// </summary>
        /// <value>The last build date.</value>
        [XmlIgnore]
        public DateTime LastBuildDate { get; set; }

        /// <summary>
        /// Gets or sets the last build date XML serialization output. This is only used 
        /// for XML serialization, since you can't really control output of serialization
        /// of a DateTime object.
        /// </summary>
        /// <value>The last build date XML serialization output.</value>
        [XmlElement(ElementName = "lastBuildDate")]
        public string LastBuildDateXmlSerializationOutput
        {
            get
            {
                return LastBuildDate.ToString(RssDocument.RSS_DATE_FORMAT, CultureInfo.GetCultureInfo(RssDocument.RSS_DATE_CULTUREINFO));
            }

            set
            {
                LastBuildDate = DateTime.Parse(value, CultureInfo.GetCultureInfo(RssDocument.RSS_DATE_CULTUREINFO));
            }
        }

        /// <summary>
        /// A URL that points to the documentation for the format used in the RSS file. 
        /// It's probably a pointer to http://blogs.law.harvard.edu/tech/rss. It's for 
        /// people who might stumble across an RSS file on a Web server 25 years from now 
        /// and wonder what it is.
        /// </summary>
        /// <value>The documentation.</value>
        [XmlElement(ElementName = "docs")]
        public string Documentation { get; set; }

        /// <summary>
        /// A string indicating the program used to generate the channel.
        /// </summary>
        /// <value>The generator.</value>
        [XmlElement(ElementName = "generator")]
        public string Generator { get; set; }

        /// <summary>
        /// Email address for person responsible for editorial content.
        /// </summary>
        /// <value>The managing editor.</value>
        [XmlElement(ElementName = "managingEditor")]
        public string ManagingEditor { get; set; }

        /// <summary>
        /// Email address for person responsible for technical issues relating to channel.
        /// </summary>
        /// <value>The web master.</value>
        [XmlElement(ElementName = "webMaster")]
        public string WebMaster { get; set; }

        /// <summary>
        /// Gets or sets the collection of items
        /// </summary>
        /// <value>The items.</value>
        [XmlElement(ElementName = "item")]
        public List<RssItem> Items { get; set; }
    }
}