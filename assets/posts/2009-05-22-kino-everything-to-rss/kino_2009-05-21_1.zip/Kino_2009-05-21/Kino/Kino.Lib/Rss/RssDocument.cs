﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssDocument.cs" company="LiteMedia">
//   Use and copy at your own lesiure.
// </copyright>
// <summary>
//   In memory representation of an RSS document
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Lib.Rss
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml;
    using System.Xml.Serialization;

    /// <summary>
    /// In memory representation of an RSS document
    /// </summary>
    [XmlRoot(ElementName = "rss")]
    public class RssDocument
    {
        public const string RSS_DATE_CULTUREINFO = "en-US";
        public const string RSS_DATE_FORMAT = "ddd, dd MMM yyyy HH':'mm':'ss 'GMT'";

        private RssChannelGenerator[] channelGenerators;

        /// <summary>
        /// Initializes a new instance of the <see cref="RssDocument"/> class.
        /// </summary>
        public RssDocument()
            : this("2.0", null)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RssDocument"/> class.
        /// </summary>
        /// <param name="version">
        /// The RSS specification version
        /// </param>
        public RssDocument(string version)
            : this(version, null)
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RssDocument"/> class.
        /// </summary>
        /// <param name="version">
        /// The RSS specification version
        /// </param>
        /// <param name="channelGenerators">
        /// The channel generators.
        /// </param>
        public RssDocument(string version, RssChannelGenerator[] channelGenerators)
        {
            Version = version;
            Channels = new List<RssChannel>();

            this.channelGenerators = channelGenerators;
        }

        /// <summary>
        /// Gets or sets the rss specification version.
        /// </summary>
        /// <value>The version.</value>
        [XmlAttribute(AttributeName = "version")]
        public string Version { get; set; }

        /// <summary>
        /// Gets or sets the channels.
        /// </summary>
        /// <value>The channels.</value>
        [XmlElement(ElementName = "channel")]
        public List<RssChannel> Channels { get; set; }

        /// <summary>
        /// Finds this documents channel by title
        /// </summary>
        /// <param name="title">
        /// The title of the channel we want to find
        /// </param>
        /// <returns>
        /// Null if channel is not found in document
        /// </returns>
        private RssChannel FindChannelByTitle(string title)
        {
            return Channels.FirstOrDefault(Channel => Channel.Title == title);
        }

        /// <summary>
        /// Removes the channel that is about to get updated from this document
        /// </summary>
        /// <param name="title">
        /// The title of the channel we're updating
        /// </param>
        private void RemoveChannelThatIsAboutToGetUpdated(string title)
        {
            RssChannel channel = FindChannelByTitle(title);
            if (channel != null)
                Channels.Remove(channel);
        }

        /// <summary>
        /// Updates the channels of this document.
        /// </summary>
        public void UpdateChannels()
        {
            if (this.Channels == null)
            {
                throw new InvalidOperationException("You can't generate channels if channelGenerators has not been passed to the constructor");
            }

            foreach (RssChannelGenerator generator in this.channelGenerators)
            {
                RemoveChannelThatIsAboutToGetUpdated(generator.Channel.Title);

                generator.UpdateChannelItems();
                Channels.Add(generator.Channel);
            }
        }

        /// <summary>
        /// Writes contents of this document to a stream as XML
        /// </summary>
        /// <param name="stream">
        /// The stream we're writing document contents to
        /// </param>
        public void WriteTo(Stream stream)
        {
            var serializer = new XmlSerializer(typeof(RssDocument));
            var settings = new XmlWriterSettings
                               {
                                   Encoding = Encoding.UTF8,
                                   OmitXmlDeclaration = true,
                                   Indent = true
                               };

            using (XmlWriter writer = XmlWriter.Create(stream, settings))
            {
                if (writer != null)
                {
                    serializer.Serialize(writer, this);
                }
            }
        }
    }
}