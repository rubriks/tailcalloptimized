﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssChannelGenerator.cs" company="LiteMedia">
//   
// </copyright>
// <summary>
//   An abstract class that defines how to dynamically generate a channel
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Lib.Rss
{
    using System;

    /// <summary>
    /// An abstract class that defines how to dynamically generate a channel
    /// </summary>
    public abstract class RssChannelGenerator
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RssChannelGenerator"/> class.
        /// </summary>
        /// <param name="title">
        /// The name of the channel. It's how people refer to your service. If you have an HTML website that contains the same information as your RSS file, the title of your channel should be the same as the title of your website.
        /// </param>
        /// <param name="link">
        /// The URL to the HTML website corresponding to the channel.
        /// </param>
        /// <param name="description">
        /// Phrase or sentence describing the channel.
        /// </param>
        /// <param name="documentation">
        /// A URL that points to the documentation for the format used in the RSS file. It's probably a pointer to http://blogs.law.harvard.edu/tech/rss. It's for people who might stumble across an RSS file on a Web server 25 years from now and wonder what it is.
        /// </param>
        /// <param name="generator">
        /// Name of this class
        /// </param>
        /// <param name="managingEditor">
        /// Email address for person responsible for editorial content.
        /// </param>
        /// <param name="webMaster">
        /// Email address for person responsible for technical issues relating to channel.
        /// </param>
        protected RssChannelGenerator(string title, string link, string description, string documentation, string generator, string managingEditor, string webMaster)
        {
            Channel = new RssChannel
                          {
                              Title = title,
                              Link = link,
                              Description = description,
                              Language = RssDocument.RSS_DATE_CULTUREINFO,
                              PublicationDate = DateTime.Now,
                              LastBuildDate = DateTime.Now,
                              Documentation = documentation,
                              Generator = generator,
                              ManagingEditor = managingEditor,
                              WebMaster = webMaster
                          };
        }


        /// <summary>
        /// Gets or sets the channel.
        /// </summary>
        /// <value>The channel.</value>
        public RssChannel Channel { get; private set; }

        /// <summary>
        /// Updates the channel items.
        /// </summary>
        public abstract void UpdateChannelItems();
    }
}