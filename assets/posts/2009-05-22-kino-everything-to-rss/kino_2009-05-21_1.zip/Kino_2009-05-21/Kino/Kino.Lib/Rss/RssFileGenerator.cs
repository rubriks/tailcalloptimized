﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssFileGenerator.cs" company="LiteMedia">
//   Use and copy at your own lesiure.
// </copyright>
// <summary>
//   Generate channel information from entities on a file system
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Lib.Rss
{
    using System.Collections.Generic;
    using System.IO;

    /// <summary>
    /// Generate channel information from entities on a file system
    /// </summary>
    public class RssFileGenerator : RssFileSystemInfoGenerator
    {
        public RssFileGenerator(string title, string link, string description, string documentation, string managingEditor, string webMaster, string basePath, string[] searchPatterns)
            : base(title, link, description, documentation, managingEditor, webMaster, basePath, searchPatterns)
        {
        }

        /// <summary>
        /// Overridden from RssFileSystemInfoGenerator
        /// </summary>
        protected override IEnumerable<FileSystemInfo> GetAllItems(DirectoryInfo baseDirectory, string[] searchPatterns)
        {
            var result = new List<FileSystemInfo>();

            foreach (string pattern in searchPatterns)
            {
                result.AddRange(GetFiles(baseDirectory, pattern));
            }

            return result;
        }

        /// <summary>
        /// Extracting this method call for unit testing purposes
        /// </summary>
        public virtual FileInfo[] GetFiles(DirectoryInfo baseDirectory, string searchPattern)
        {
            return baseDirectory.GetFiles(searchPattern, SearchOption.AllDirectories);
        }
    }
}