﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Kino.Lib.Rss;
using System.IO;
using Rhino.Mocks;

namespace Kino.Tests.Rss.RssFileSystemInfoGeneratorTest
{
    [TestClass]
    public class UpdateChannelItemsTest
    {
        private const string Title = "Mint blog posts";
        private const string Link = "http://mint.litemedia.se";
        private const string Description = "My blog posts of the Mint blog";
        private const string Documentation = "http://blogs.law.harvard.edu/tech/rss";
        private const string ManagingEditor = "mikael.lundin@litemedia.se";
        private const string WebMaster = "mikael.lundin@litemedia.se";

        [TestMethod]
        public void ShouldUpdateChannelItemsFromAListOfFileSystemInfos()
        {
            /* Setup */
            RssFileSystemInfoGenerator generator = new TestChannelGenerator(Title, Link, Description, Documentation, ManagingEditor, WebMaster);

            /* Test */
            generator.UpdateChannelItems();

            /* Assert */
            Assert.AreEqual(1, generator.Channel.Items.Count);
        }

        [TestMethod]
        public void PublicationDateShouldBeSetToCreationTimeGMT()
        {
            /* Setup */
            var includedDirectory = new DirectoryInfo(Environment.CurrentDirectory);
            RssFileSystemInfoGenerator generator = new TestChannelGenerator(Title, Link, Description, Documentation, ManagingEditor, WebMaster);

            /* Test */
            generator.UpdateChannelItems();

            /* Assert */
            Assert.AreEqual(includedDirectory.CreationTime.ToUniversalTime(), generator.Channel.Items[0].PublicationDate);
        }

        /// <summary>
        /// A fake class so we can override GetAllItems(..) for testing purposes
        /// </summary>
        private class TestChannelGenerator : RssFileSystemInfoGenerator
        {
            public TestChannelGenerator(string title, string link, string description, string documentation, string managingEditor, string webMaster)
            : base(title, link, description, documentation, managingEditor, webMaster, Environment.CurrentDirectory, new string[0])
            {
            }

            protected override IEnumerable<FileSystemInfo> GetAllItems(DirectoryInfo baseDirectory, string[] searchPatterns)
            {
                List<FileSystemInfo> result = new List<FileSystemInfo>();
                result.Add(new DirectoryInfo(Environment.CurrentDirectory));
                return result;
            }
        }
    }
}
