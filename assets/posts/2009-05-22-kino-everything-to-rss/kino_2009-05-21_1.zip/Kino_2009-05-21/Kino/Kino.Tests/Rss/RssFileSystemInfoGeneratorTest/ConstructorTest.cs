﻿namespace Kino.Tests.Rss.RssFileSystemInfoGeneratorTest
{
    using System;
    using System.Linq;
    using Kino.Lib.Rss;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class ConstructorTest
    {
        private const string Title = "Mint blog posts";
        private const string Link = "http://mint.litemedia.se";
        private const string Description = "My blog posts of the Mint blog";
        private const string Documentation = "http://blogs.law.harvard.edu/tech/rss";
        private const string ManagingEditor = "mikael.lundin@litemedia.se";
        private const string WebMaster = "mikael.lundin@litemedia.se";

        [TestMethod]
        public void CreatingNewInstanceWithoutSearchPatternsWillSetDefaultSearchPattern()
        {
            /* Test */
            var generator = new RssFileSystemInfoGenerator(Title, Link, Description, Documentation, ManagingEditor, WebMaster, Environment.CurrentDirectory, new string[0]);

            /* Assert */
            Assert.AreEqual(RssFileSystemInfoGenerator.DefaultSearchPattern, generator.SearchPatterns[0]);
        }

        [TestMethod]
        public void CreatingNewInstanceWillSetBaseDirectoryToSuppliedPath()
        {
            /* Setup */
            string path = Environment.CurrentDirectory;

            /* Test */
            var generator = new RssFileSystemInfoGenerator(Title, Link, Description, Documentation, ManagingEditor, WebMaster, path, new string[0]);

            /* Assert */
            Assert.AreEqual(path, generator.BaseDirectory.FullName);
        }

        [TestMethod]
        public void CreatingNewInstanceWillSetSearchPatternsToSuppliedPatterns()
        {
            /* Setup */
            string[] searchPatterns = {"*.wmv", "*.avi", "*.mp*g"};

            /* Test */
            var generator = new RssFileSystemInfoGenerator(Title, Link, Description, Documentation, ManagingEditor, WebMaster, Environment.CurrentDirectory, searchPatterns);

            /* Assert */
            // All supplied patterns are included in generator.SearchPatterns
            Assert.IsTrue(
                searchPatterns.All(pattern => generator.SearchPatterns.Contains(pattern))
                );
        }
    }
}
