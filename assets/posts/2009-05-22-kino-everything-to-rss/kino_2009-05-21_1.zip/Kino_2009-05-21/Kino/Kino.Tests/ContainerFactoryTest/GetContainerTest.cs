﻿namespace Kino.Tests.ContainerFactoryTest
{
    using System.Configuration;
    using Kino.Lib;
    using Microsoft.VisualStudio.TestTools.UnitTesting;

    [TestClass]
    public class GetContainerTest
    {
        [TestMethod]
        public void ShouldGetRssDocumentsContainer()
        {
            /* Test */
            var container = ContainerFactory.Instance.GetContainer(ContainerFactory.RssDocuments);

            /* Assert */
            Assert.IsNotNull(container);
        }

        [TestMethod]
        [ExpectedException(typeof(ConfigurationErrorsException))]
        public void ShouldThrowConfigurationErrorsExceptionWhenContainerWasNotFound()
        {
            /* Setup */
            string unknownContainer = "unknown";

            /* Test */
            ContainerFactory.Instance.GetContainer(unknownContainer);
        }
    }
}
