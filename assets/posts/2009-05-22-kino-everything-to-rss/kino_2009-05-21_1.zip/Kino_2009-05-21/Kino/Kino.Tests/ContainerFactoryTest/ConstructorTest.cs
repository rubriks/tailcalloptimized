﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Kino.Lib;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Kino.Tests.ContainerFactoryTest
{
    [TestClass]
    public class ConstructorTest
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ShouldThrowArgumentNullExceptionOnConfigurationSection()
        {
            /* Test */
            new ContainerFactory(null);
        }
    }
}
