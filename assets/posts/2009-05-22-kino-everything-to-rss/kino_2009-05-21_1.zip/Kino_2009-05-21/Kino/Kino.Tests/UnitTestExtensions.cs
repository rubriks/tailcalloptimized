﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="UnitTestExtensions.cs" company="LiteMedia">
//   
// </copyright>
// <summary>
//   Defines the UnitTestExtensions type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Tests
{
    using System;
    using System.Reflection;

    /// <summary>
    /// Help methods for performing unit tests
    /// </summary>
    public static class UnitTestExtensions
    {
        /// <summary>
        /// Gets a private field from instance. Note that it is not recommended to unit test private parts of a class. Only use it when you have validated your options through the public interface of the class.
        /// </summary>
        /// <typeparam name="T">Type of the private field</typeparam>
        /// <param name="instance">The instance we would like to get the private field from</param>
        /// <param name="name">The name of the private field</param>
        /// <returns>The private field from this instance, or null if it does not exist</returns>
        public static T GetField<T>(this object instance, string name)
        {
            Type t = instance.GetType();

            FieldInfo f = t.GetField(name, BindingFlags.Instance
                                                  | BindingFlags.NonPublic
                                                  | BindingFlags.Public);

            return (T)f.GetValue(instance);
        }
    }
}
