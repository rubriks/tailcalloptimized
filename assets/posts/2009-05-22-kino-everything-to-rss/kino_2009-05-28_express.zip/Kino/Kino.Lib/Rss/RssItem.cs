﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssItem.cs" company="LiteMedia">
//   Use and copy at your own lesiure.
// </copyright>
// <summary>
//   In in memory object representation of the rss item element
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Lib.Rss
{
    using System;
    using System.Globalization;
    using System.Xml.Serialization;

    /// <summary>
    /// In in memory object representation of the rss item element
    /// </summary>
    public class RssItem
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="RssItem"/> class. This empty constructor is neccessary for XmlSerialization
        /// </summary>
        public RssItem()
        {
            // Neccessary for XmlSerialization
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="RssItem"/> class. This constructor will make it easier to create a valid instance of RssItem
        /// </summary>
        /// <param name="title">
        /// The title of the item.
        /// </param>
        /// <param name="link">
        /// The URL of the item.
        /// </param>
        /// <param name="description">
        /// The item synopsis.
        /// </param>
        /// <param name="publicationDate">
        /// Indicates when the item was published.
        /// </param>
        public RssItem(string title, string link, string description, DateTime publicationDate)
        {
            Title = title;
            Link = link;
            Description = description;
            PublicationDate = publicationDate;
        }

        /// <summary>
        /// The title of the item.
        /// </summary>
        /// <value>The title.</value>
        [XmlElement(ElementName = "title")]
        public string Title { get; set; }

        /// <summary>
        /// The URL of the item.
        /// </summary>
        /// <value>The link.</value>
        [XmlElement(ElementName = "link")]
        public string Link { get; set; }

        /// <summary>
        /// The item synopsis.
        /// </summary>
        /// <value>The description.</value>
        [XmlElement(ElementName = "description")]
        public string Description { get; set; }

        /// <summary>
        /// Indicates when the item was published. Note that this is GMT.
        /// </summary>
        /// <value>The publication date.</value>
        [XmlIgnore]
        public DateTime PublicationDate { get; set; }

        /// <summary>
        /// Gets or sets the publication date XML serialization output. This is only used 
        /// for XML serialization, since you can't really control output of serialization
        /// of a DateTime object.
        /// </summary>
        /// <value>The publication date XML serialization output.</value>
        [XmlElement(ElementName = "pubDate")]
        public string PublicationDateXmlSerializationOutput
        {
            get
            {
                return PublicationDate.ToString(RssDocument.RSS_DATE_FORMAT, CultureInfo.GetCultureInfo(RssDocument.RSS_DATE_CULTUREINFO));
            }
            set
            {
                PublicationDate = DateTime.Parse(value, CultureInfo.GetCultureInfo(RssDocument.RSS_DATE_CULTUREINFO));
            }
        }
    }
}