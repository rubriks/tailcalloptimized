﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssFileSystemInfoGenerator.cs" company="LiteMedia">
//   Use and copy at your own lesiure.
// </copyright>
// <summary>
//   Generate channel information from files and directories on a file system
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Lib.Rss
{
    using System;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.IO;
    using System.Linq;

    /// <summary>
    /// Generate channel information from files and directories on a file system
    /// </summary>
    public class RssFileSystemInfoGenerator : RssChannelGenerator
    {
        public const string DefaultSearchPattern = "*";
        private const string GeneratorName = "Kino.Lib.Rss.RssFileSystemInfoGenerator";
        
        private readonly DirectoryInfo baseDirectory;
        private readonly string[] searchPatterns;

        /// <summary>
        /// Initializes a new instance of the <see cref="RssFileSystemInfoGenerator"/> class. 
        /// </summary>
        /// <param name="title">
        /// The name of the channel. It's how people refer to your service. If you have an HTML website that contains the same information as your RSS file, the title of your channel should be the same as the title of your website.
        /// </param>
        /// <param name="link">
        /// The URL to the HTML website corresponding to the channel.
        /// </param>
        /// <param name="description">
        /// Phrase or sentence describing the channel.
        /// </param>
        /// <param name="documentation">
        /// A URL that points to the documentation for the format used in the RSS file. It's probably a pointer to http://blogs.law.harvard.edu/tech/rss. It's for people who might stumble across an RSS file on a Web server 25 years from now and wonder what it is.
        /// </param>
        /// <param name="managingEditor">
        /// Email address for person responsible for editorial content.
        /// </param>
        /// <param name="webMaster">
        /// Email address for person responsible for technical issues relating to channel.
        /// </param>
        /// <param name="basePath">
        /// The path from where search starts.
        /// </param>
        /// <param name="searchPatterns">
        /// The search patterns used when finding files. If you supply no search pattern, a default search pattern "*" will be set
        /// </param>
        public RssFileSystemInfoGenerator(string title, string link, string description, string documentation, string managingEditor, string webMaster, string basePath, string[] searchPatterns)
            : base(title, link, description, documentation, GeneratorName, managingEditor, webMaster)
        {
            baseDirectory = new DirectoryInfo(basePath);

            // If no searchPatterns have been supplied, default behaviour should be to include all FileSystemInfos
            if (searchPatterns.Length > 0)
            {
                this.searchPatterns = searchPatterns;
            }
            else
            {
                this.searchPatterns = new[] { DefaultSearchPattern };
            }
        }

        /// <summary>
        /// Gets the search patterns set for this instance.
        /// </summary>
        /// <value>The search patterns.</value>
        public ReadOnlyCollection<string> SearchPatterns
        {
            get { return new ReadOnlyCollection<string>(this.searchPatterns); }
        }

        /// <summary>
        /// Gets the base directory from where search should originate
        /// </summary>
        /// <value>The base directory.</value>
        public DirectoryInfo BaseDirectory
        {
            get { return this.baseDirectory; }   
        }

        /// <summary>
        /// Gets all file system items.
        /// </summary>
        /// <returns>
        /// A list of file system entities (infos) as a result of the search
        /// </returns>
        protected virtual IEnumerable<FileSystemInfo> GetAllItems(DirectoryInfo baseDirectory, string[] searchPatterns)
        {
            throw new NotImplementedException("Implement this if you ever need it");
        }

        /// <summary>
        /// Creates an RssItem from an FileSystemInfo
        /// </summary>
        /// <param name="info">The FileSystemInfo to use as template.</param>
        /// <returns>An RssItem</returns>
        private RssItem CreateRssItem(FileSystemInfo info)
        {
            string title = info.Name;
            string link = "file://" + info.FullName;
            string description = string.Format("A new movie has been published at:\n{0}", info.FullName);
            DateTime publicationDate = info.CreationTime.ToUniversalTime();

            return new RssItem(title, link, description, publicationDate);
        }


        /// <summary>
        /// Gets the RSS items
        /// </summary>
        /// <param name="baseDirectory">The base directory.</param>
        /// <returns>An ordered list of RSS items</returns>
        private List<RssItem> GetItems(DirectoryInfo baseDirectory)
        {
            List<RssItem> result = (from FileSystemInfo in GetAllItems(baseDirectory, searchPatterns)
                                    orderby FileSystemInfo.CreationTime descending
                                    select CreateRssItem(FileSystemInfo)).ToList();

            return result;
        }

        /// <summary>
        /// Find the RSS item with the latest date.
        /// </summary>
        /// <returns>
        /// Default date if no items were found in collection
        /// </returns>
        private DateTime GetLatestDate(IEnumerable<RssItem> items)
        {
            DateTime result = (from RssItem in items
                               orderby RssItem.PublicationDate descending
                               select RssItem.PublicationDate).FirstOrDefault();

            return result;
        }

        /// <summary>
        /// Updates the channel items.
        /// </summary>
        public override void UpdateChannelItems()
        {
            this.Channel.Items = GetItems(baseDirectory);
            this.Channel.LastBuildDate = GetLatestDate(this.Channel.Items);
            this.Channel.PublicationDate = GetLatestDate(this.Channel.Items);
        }
    }
}