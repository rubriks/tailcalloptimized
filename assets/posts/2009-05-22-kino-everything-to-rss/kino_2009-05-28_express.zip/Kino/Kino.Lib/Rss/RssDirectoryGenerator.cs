﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssDirectoryGenerator.cs" company="LiteMedia">
//   Use and copy at your own lesiure.
// </copyright>
// <summary>
//   Used to generate RSS items from a directory structure
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.Lib.Rss
{
    using System.Collections.Generic;
    using System.IO;

    /// <summary>
    /// Used to generate RSS items from a directory structure
    /// </summary>
    public class RssDirectoryGenerator : RssFileSystemInfoGenerator
    {
        public RssDirectoryGenerator(string title, string link, string description, string documentation,
                                     string managingEditor, string webMaster, string basePath, string[] searchPatterns)
            : base(title, link, description, documentation, managingEditor, webMaster, basePath, searchPatterns)
        {
        }

        /// <summary>
        /// Overridden from RssFileSystemInfoGenerator
        /// </summary>
        protected override IEnumerable<FileSystemInfo> GetAllItems(DirectoryInfo baseDirectory, string[] searchPatterns)
        {
            var result = new List<FileSystemInfo>();

            foreach (string pattern in searchPatterns)
            {
                result.AddRange(GetDirectories(baseDirectory, pattern));
            }

            return result;
        }

        /// <summary>
        /// Extracting this method call for unit testing purposes
        /// </summary>
        public virtual DirectoryInfo[] GetDirectories(DirectoryInfo baseDirectory, string searchPattern)
        {
            return baseDirectory.GetDirectories(searchPattern, SearchOption.AllDirectories);
        }
    }
}