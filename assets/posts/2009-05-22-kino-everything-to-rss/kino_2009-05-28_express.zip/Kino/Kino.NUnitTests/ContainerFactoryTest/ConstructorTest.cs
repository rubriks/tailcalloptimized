﻿namespace Kino.NUnitTests.ContainerFactoryTest
{
    using System;
    using Kino.Lib;
    using NUnit.Framework;

    [TestFixture]
    public class ConstructorTest
    {
        [Test]
        public void ShouldThrowArgumentNullExceptionOnConfigurationSection()
        {
            /* Test / Assert */
            Assert.Throws<ArgumentNullException>( 
                ()=> new ContainerFactory(null));
        }
    }
}
