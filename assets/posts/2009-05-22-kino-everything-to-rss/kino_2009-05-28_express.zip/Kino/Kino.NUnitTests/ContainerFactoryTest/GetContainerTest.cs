﻿namespace Kino.NUnitTests.ContainerFactoryTest
{
    using System.Configuration;
    using Kino.Lib;
    using NUnit.Framework;

    [TestFixture]
    public class GetContainerTest
    {
        [Test]
        public void ShouldGetRssDocumentsContainer()
        {
            /* Test */
            var container = ContainerFactory.Instance.GetContainer(ContainerFactory.RssDocuments);

            /* Assert */
            Assert.IsNotNull(container);
        }

        [Test]
        public void ShouldThrowConfigurationErrorsExceptionWhenContainerWasNotFound()
        {
            /* Setup */
            string unknownContainer = "unknown";

            /* Test */
            Assert.Throws<ConfigurationErrorsException>(
                () => ContainerFactory.Instance.GetContainer(unknownContainer));
        }
    }
}
