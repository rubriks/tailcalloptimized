﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssDocumentTest.cs" company="LiteMedia">
//   Please distribute this as you like. 
//   If you change something and redistribute, 
//   please aknowledge the original author. Thank you!
// </copyright>
// <summary>
//   Defines the RssDocumentTest type.
// </summary>
// <author>
//   Mikael Lundin (mikael.lundin@litemedia.se)
// </author>
// --------------------------------------------------------------------------------------------------------------------

namespace Kino.NUnitTests.Rss.RssDocumentTest
{
    using System.IO;
    using System.Reflection;
    using System.Xml;
    using System.Xml.Schema;
    using Kino.Lib.Rss;
    using NUnit.Framework;
    using System.Xml.Serialization;
    using System;

    [TestFixture]
    public class WriteToTest
    {
        private const string RssSchemaPath = "Kino.NUnitTests.Rss.RssDocumentTest.rss_2.0.xsd";
        private const string RssSamplePath = "Kino.NUnitTests.Rss.RssDocumentTest.sample.rss";

        private const string Title = "Mint blog posts";
        private const string Link = "http://mint.litemedia.se";
        private const string Description = "My blog posts of the Mint blog";
        private const string Documentation = "http://blogs.law.harvard.edu/tech/rss";
        private const string ManagingEditor = "mikael.lundin@litemedia.se";
        private const string WebMaster = "mikael.lundin@litemedia.se";

        /// <summary>
        /// This is really an integration test. Too bad that MSTest does not support categories, 
        /// or I would make sure to categorize this as one. I don't really think it is neccessary 
        /// to create a seperate assembly either for just one test.
        /// </summary>
        [Test]
        public void SerializedXmlConformsToSchema()
        {
            /* Setup */
            RssDocument document = new RssDocument("2.0", GetChannelGenerators());
            document.UpdateChannels();

            // Stream we're serializing to
            MemoryStream documentStream = new MemoryStream();

            // XSD of Rss 2.0
            Stream xsd = GetResourceStream(RssSchemaPath);

            /* Test */
            document.WriteTo(documentStream);

            /* Assert */
            documentStream.Position = 0;

            XmlDocument rssDocument = new XmlDocument();
            rssDocument.Load(documentStream);

            using (TextReader schemaReader = new StreamReader(xsd))
            {
                XmlSchema schema = XmlSchema.Read(schemaReader, ValidationCallBack);
                rssDocument.Schemas.Add(schema);

                rssDocument.Validate(ValidationCallBack);
            }
        }

        [Test]
        public void CanDeserializeRss()
        {
            /* Setup */
            DateTime expectedDate = new DateTime(2009, 5, 17, 18, 35, 57).ToLocalTime();
            XmlSerializer serializer = new XmlSerializer(typeof(RssDocument));
            Stream rssStream = GetResourceStream(RssSamplePath);
            RssDocument document = null;

            /* Test */
            using (XmlReader reader = XmlReader.Create(rssStream))
            {
                document = serializer.Deserialize(reader) as RssDocument;
            }

            /* Assert */
            Assert.IsNotNull(document);
            Assert.AreEqual(1, document.Channels.Count);
            Assert.AreEqual(2, document.Channels[0].Items.Count);
            Assert.AreEqual(expectedDate, document.Channels[0].Items[1].PublicationDate);
        }

        private static Stream GetResourceStream(string path)
        {
            Assembly assembly = Assembly.GetCallingAssembly();
            Stream result = assembly.GetManifestResourceStream(path);

            return result;
        }

        private static void ValidationCallBack(object sender, ValidationEventArgs e)
        {
            Assert.Fail(e.Message);
        }

        private static RssChannelGenerator[] GetChannelGenerators()
        {
            return new RssChannelGenerator[]
                       {
                           new RssTestGenerator(Title, Link, Description, Documentation, ManagingEditor, WebMaster)
                       };
        }
    }
}
