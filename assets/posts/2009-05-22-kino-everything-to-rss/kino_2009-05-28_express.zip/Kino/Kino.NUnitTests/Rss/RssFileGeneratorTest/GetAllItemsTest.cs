﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NUnit.Framework;
using Rhino.Mocks;
using Kino.Lib.Rss;
using System.IO;

namespace Kino.NUnitTests.Rss.RssFileGeneratorTest
{
    [TestFixture]
    public class GetAllItemsTest
    {
        private const string Title = "Mint blog posts";
        private const string Link = "http://mint.litemedia.se";
        private const string Description = "My blog posts of the Mint blog";
        private const string Documentation = "http://blogs.law.harvard.edu/tech/rss";
        private const string ManagingEditor = "mikael.lundin@litemedia.se";
        private const string WebMaster = "mikael.lundin@litemedia.se";

        [Test]
        public void ShouldRetrieveFilesMatchingAllPatterns()
        {
            /* Setup */
            string baseDirectory = Environment.CurrentDirectory;
            string[] searchPatterns = new string[] { "*.wmv", "*.avi", "*.mp*g" };

            MockRepository mocks = new MockRepository();
            var generator = mocks.PartialMock<RssFileGenerator>(Title, Link, Description, Documentation, ManagingEditor, WebMaster, baseDirectory, searchPatterns);

            /* Expect */
            for (int i = 0; i < searchPatterns.Length; i++)
            {
                generator.Expect(g => g.GetFiles(g.BaseDirectory, searchPatterns[i])).Return(new FileInfo[0]);
            }

            /* Replay */
            mocks.ReplayAll();
            generator.UpdateChannelItems();
            mocks.VerifyAll();
        }
    }
}
