using System;
using System.Collections.Generic;
using Kino.Lib.Rss;

namespace Kino.NUnitTests.Rss
{
    public class RssTestGenerator : RssChannelGenerator
    {
        private const string RSS_CHANNEL_GENERATOR = "Kino.Tests.Rss.RssTestGenerator";

        public RssTestGenerator(string title, string link, string description, string documentation, string managingEditor, string webmaster)
            : base(title, link, description, documentation, RSS_CHANNEL_GENERATOR, managingEditor, webmaster)
        {
        }

        private RssItem CreateRssItem(int counter)
        {
            string i = counter.ToString();
            return new RssItem
                       {
                           Title = "Title " + i,
                           Description = "Description " + i,
                           Link = "http://mint.litemedia.se/" + i,
                           PublicationDate = DateTime.Now.ToUniversalTime()
                       };
        }


        public override void UpdateChannelItems()
        {
            List<RssItem> items = new List<RssItem>();

            for (int i = 0; i < 10; i++)
                items.Add(CreateRssItem(i));

            this.Channel.Items = items;
        }
    }
}
