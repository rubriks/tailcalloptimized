﻿using NUnit.Framework;
using Kino.Lib.Rss;

namespace Kino.NUnitTests.Rss.RssChannelGeneratorTest
{
    [TestFixture]
    public class ConstructorTest
    {
        private const string Title = "Mint blog posts";
        private const string Link = "http://mint.litemedia.se";
        private const string Description = "My blog posts of the Mint blog";
        private const string Documentation = "http://blogs.law.harvard.edu/tech/rss";
        private const string ManagingEditor = "mikael.lundin@litemedia.se";
        private const string WebMaster = "mikael.lundin@litemedia.se";


        [Test]
        public void WillSetChannelProperties()
        {
            /* Test */
            RssChannelGenerator generator = new RssTestGenerator(Title, Link, Description, Documentation, ManagingEditor, WebMaster);

            /* Assert */
            Assert.IsNotNull(generator.Channel);

            // These assert values comes from Unity.config. Changes there will break this test
            Assert.AreEqual(Title, generator.Channel.Title);
            Assert.AreEqual(Link, generator.Channel.Link);
            Assert.AreEqual(Description, generator.Channel.Description);
            Assert.AreEqual(Documentation, generator.Channel.Documentation);
            Assert.AreEqual(ManagingEditor, generator.Channel.ManagingEditor);
            Assert.AreEqual(WebMaster, generator.Channel.WebMaster);
        }
    }
}
