﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="RssItemTest.cs" company="LiteMedia">
//   
// </copyright>
// <summary>
//   Defines the RssItemTest type.
// </summary>
// --------------------------------------------------------------------------------------------------------------------


namespace Kino.NUnitTests.Rss
{
    using System;
    using NUnit.Framework;
    using Kino.Lib.Rss;

    [TestFixture]
    public class ConstructorTest
    {
        private const string Title = "Test title";
        private const string Link = "http://mint.litemedia.se";
        private const string Description = "This is a short synopsis";

        [Test]
        public void ShouldSetPropertiesOnCreate()
        {
            /* Setup */
            DateTime publicationDate = DateTime.Now;

            /* Test */
            RssItem item = new RssItem(Title, Link, Description, publicationDate);

            /* Assert */
            Assert.AreEqual(Title, item.Title);
            Assert.AreEqual(Link, item.Link);
            Assert.AreEqual(Description, item.Description);
            Assert.AreEqual(publicationDate, item.PublicationDate);
        }
    }
}
