using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Ajax;
using Kino.Lib;
using Kino.Lib.Rss;
using System.Text;
using System.IO;

namespace Kino.Controllers
{
    public class RssController : Controller
    {
        //
        // GET: /Rss/

        public ActionResult Index(string name)
        {
            Response.ContentEncoding = Encoding.UTF8;
            Response.ContentType = "application/rss+xml";

            var container = ContainerFactory.Instance.GetContainer(ContainerFactory.RssDocuments);
            var document = container.Resolve<RssDocument>(name);

            document.UpdateChannels();
            document.WriteTo(Response.OutputStream);

            Response.Flush();
            Response.End();
            return null;
        }

    }
}
