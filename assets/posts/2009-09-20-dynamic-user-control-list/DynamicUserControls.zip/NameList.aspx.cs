﻿namespace DynamicUserControls
{
    using System;
    using System.Collections.Generic;
    using System.Web.UI;

    public partial class NameList : Page, IDynamicControlContainer
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            foreach (string id in LoadControlIdList())
            {
                Create(id);
            }
        }

        protected void AddButton_Click(object sender, EventArgs e)
        {
            Create(null);
        }

        public void Create(string id)
        {
            string targetId = id ?? Guid.NewGuid().ToString();
            var control = LoadControl("~/NameControl.ascx");
            control.ID = targetId;

            DynamicNameList.Controls.Add(control);
            SaveControlIdList();
        }

        public void Delete(Control control)
        {
            DynamicNameList.Controls.Remove(control);
            SaveControlIdList();
        }

        public void SaveControlIdList()
        {
            List<string> idList = new List<string>();
            foreach (Control control in DynamicNameList.Controls)
            {
                idList.Add(control.ID);
            }

            ViewState["IdList"] = idList;
        }

        public string[] LoadControlIdList()
        {
            var list = (List<string>)ViewState["IdList"];

            if (list == null)
            {
                return new string[0];
            }
            return list.ToArray();
        }
    }
}
