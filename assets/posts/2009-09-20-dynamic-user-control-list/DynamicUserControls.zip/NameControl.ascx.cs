﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DynamicUserControls
{
    public partial class NameControl : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

protected void DeleteButton_Click(object sender, EventArgs e)
{
    ((IDynamicControlContainer)this.Page).Delete(this);
}
    }
}