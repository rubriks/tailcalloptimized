﻿using System.Web.UI;

namespace DynamicUserControls
{
    public interface IDynamicControlContainer
    {
        /// <summary>
        /// Creates a control on the container
        /// </summary>
        /// <param name="id">The id.</param>
        void Create(string id);

        /// <summary>
        /// Deletes the specified control from the container
        /// </summary>
        /// <param name="control">The control.</param>
        void Delete(Control control);

        /// <summary>
        /// Persist all control ids
        /// </summary>
        void SaveControlIdList();

        /// <summary>
        /// Load all control ids from persistance
        /// </summary>
        /// <returns>A list of ids</returns>
        string[] LoadControlIdList();
    }
}
