﻿namespace LiteMedia.BookStore.Tests.BookRepository
{
    using Lib;
    using NUnit.Framework;

    [TestFixture]
    public class GetAuthorsForBook
    {
        [Test]
        public void ShouldGetAllAuthorsForBook()
        {
            /* Setup */
            var repository = new StoreRepository();

            /* Test */
            var authors = repository.GetAuthorsForBook("ISBN9789127121867");

            /* Assert */
            Assert.That(authors.Count, Is.EqualTo(2));
        }
    }
}
