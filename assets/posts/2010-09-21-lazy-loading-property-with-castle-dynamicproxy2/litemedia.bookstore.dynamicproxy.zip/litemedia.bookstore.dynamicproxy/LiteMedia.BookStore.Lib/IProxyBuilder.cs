﻿namespace LiteMedia.BookStore.Lib
{
    public interface IProxyBuilder
    {
        T ProxyFromClass<T>() where T : class;
    }
}
