﻿using Castle.Core.Interceptor;
using LiteMedia.BookStore.Lib.Model;

namespace LiteMedia.BookStore.Lib
{
    public class LazyLoadAuthorsInterceptor : IInterceptor
    {
        private readonly IStoreRepository repository;
        private const string MethodName = "get_Authors";

        public LazyLoadAuthorsInterceptor(IStoreRepository repository)
        {
            this.repository = repository;
        }

        public void Intercept(IInvocation invocation)
        {
            if (invocation.Method.Name == MethodName)
            {
                var isbn = ((Book) invocation.InvocationTarget).Isbn;
                invocation.ReturnValue = repository.GetAuthorsForBook(isbn);
            }
        }
    }
}
