﻿using System.Web.Mvc;

namespace LiteMedia.BookStore.Lib.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            var repository = new StoreRepository(new ProxyBuilder(new[] { new LazyLoadAuthorsInterceptor(new StoreRepository()) }));
            var books = repository.GetAll();
            return View(books);
        }
    }
}
