﻿namespace LiteMedia.BookStore.Lib
{
    using System.Collections.Generic;
    using Model;

    public interface IStoreRepository
    {
        IList<Book> GetAll();

        IList<Author> GetAuthorsForBook(string isbn);
    }
}
