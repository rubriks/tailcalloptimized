﻿using System;

namespace LiteMedia.BookStore.Lib
{
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using System.Xml;
    using System.Xml.Linq;
    using System.Xml.Schema;
    using Model;

    public class StoreRepository : IStoreRepository
    {
        private readonly IProxyBuilder proxyBuilder;
        private const string XmlDataSourcePath = "LiteMedia.BookStore.Lib.Data.BookStore.xml";
        private const string XsdDataSourcePath = "LiteMedia.BookStore.Lib.Data.BookStore.xsd";

        public StoreRepository()
            : this(null)
        {
        }

        public StoreRepository(IProxyBuilder proxyBuilder)
        {
            this.proxyBuilder = proxyBuilder;
        }

        protected Func<IProxyBuilder, Book> CreateBook = proxyBuilder => proxyBuilder != null ? proxyBuilder.ProxyFromClass<Book>() : new Book();

        public IList<Book> GetAll()
        {
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(XmlDataSourcePath))
            {
                var doc = XDocument.Load(stream);
                XNamespace @namespace = "http://litemedia.se/BookStore.xsd";

                return doc.Root.Elements(@namespace + "book").Select(node =>
                {
                    var book = CreateBook(proxyBuilder);

                    book.Isbn = node.Attribute("id").Value;
                    book.Title = node.Element(@namespace + "title").Value;
                    book.Cover = node.Element(@namespace + "cover").Value;

                    return book;
                }).ToList();
            }
        }

        public IList<Author> GetAuthorsForBook(string isbn)
        {
            using (var xmlStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(XmlDataSourcePath))
            using (var xsdStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(XsdDataSourcePath))
            {
                var doc = new XmlDocument();

                // Load schema
                var schema = XmlSchema.Read(xsdStream, SchemaEvents);
                doc.Schemas.Add(schema);

                // Load document
                doc.Load(xmlStream);

                // Load default namespace: bs
                var nsmgr = new XmlNamespaceManager(doc.NameTable);
                nsmgr.AddNamespace("bs", "http://litemedia.se/BookStore.xsd");

                // We should be able to do this
                // var path = string.Format("id(id('{0}')/bs:author-ref/@id)", isbn);

                // but this will have to do
                var path = string.Format("/bs:bookstore/bs:author[@id[contains(/bs:bookstore/bs:book[@id='{0}']/bs:author-ref/@id,.)]]", isbn);

                return doc.SelectNodes(path, nsmgr).Cast<XmlNode>()
                    .Select(node =>
                    new Author
                    {
                        Name = node.InnerText
                    }).ToList();
            }
        }

        private void SchemaEvents(object sender, ValidationEventArgs e)
        {
            // Log the event here!
        }
    }
}
