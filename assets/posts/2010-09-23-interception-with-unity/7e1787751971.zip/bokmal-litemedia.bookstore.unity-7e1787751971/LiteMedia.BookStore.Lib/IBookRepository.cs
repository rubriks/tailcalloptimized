﻿namespace LiteMedia.BookStore.Lib
{
    using System.Collections.Generic;
    using Model;

    public interface IBookRepository
    {
        IList<Book> GetAll();
    }
}
