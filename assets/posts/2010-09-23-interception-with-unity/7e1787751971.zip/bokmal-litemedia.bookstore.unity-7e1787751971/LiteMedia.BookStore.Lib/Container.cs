﻿using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.InterceptionExtension;
using IInterceptor = Castle.Core.Interceptor.IInterceptor;

namespace LiteMedia.BookStore.Lib
{
    public class Container : UnityContainer
    {
        private const string NoProxyBuilder = "NoProxyBuilder";
        private const string LazyLoadProxyBuilder = "LazyLoadProxyBuilder";

        private const string LazyLoadAuthorsInterceptor = "LazyLoadAuthorsInterceptor";
        private const string MeasureLatencyCallHandler = "MeasureLatencyCallHandler";
        private const string AnyMatchingRule = "AnyMatchingRule";

        private static IUnityContainer instance;
        private static readonly object Padlock = new object();

        public Container()
        {
            this.RegisterType<IAuthorRepository, StoreRepository>(NoProxyBuilder, new InjectionConstructor());
            this.RegisterType<IBookRepository, StoreRepository>(new InjectionConstructor(new ResolvedParameter<IProxyBuilder>(LazyLoadProxyBuilder)));
            this.RegisterType<IProxyBuilder, ProxyBuilder>(LazyLoadProxyBuilder,
                new InjectionConstructor(
                    new ResolvedArrayParameter<IInterceptor>(
                        new ResolvedParameter<IInterceptor>(LazyLoadAuthorsInterceptor))));

            this.RegisterType<IInterceptor, LazyLoadAuthorsInterceptor>(LazyLoadAuthorsInterceptor,
                new InjectionConstructor(new ResolvedParameter<IAuthorRepository>(NoProxyBuilder)));

            InitializeInterception();
        }

        public static IUnityContainer Current
        {
            get
            {
                lock(Padlock)
                {
                    if (instance == null)
                    {
                        instance = new Container();
                    }

                    return instance;
                }
            }
        }

        private void InitializeInterception()
        {
            this.AddNewExtension<Interception>();

            this.RegisterType<IMatchingRule, AnyMatchingRule>(AnyMatchingRule);
            this.RegisterType<ICallHandler, MeasureLatencyCallHandler>(MeasureLatencyCallHandler);

            this.Configure<Interception>().AddPolicy("TracePolicy")
                .AddMatchingRule(AnyMatchingRule)
                .AddCallHandler(MeasureLatencyCallHandler);

            this.Configure<Interception>().SetInterceptorFor(typeof(IBookRepository), new InterfaceInterceptor());
            this.Configure<Interception>().SetInterceptorFor(typeof(IAuthorRepository), NoProxyBuilder, new InterfaceInterceptor());
        }
    }
}
