﻿using System.Web.Mvc;
using Microsoft.Practices.Unity;

namespace LiteMedia.BookStore.Lib.Controllers
{
    public class HomeController : Controller
    {
        public ViewResult Index()
        {
            var repository = Container.Current.Resolve<IBookRepository>();
            var books = repository.GetAll();
            return View(books);
        }
    }
}
