﻿using System.Diagnostics;
using Microsoft.Practices.Unity.InterceptionExtension;

namespace LiteMedia.BookStore.Lib
{
    public class MeasureLatencyCallHandler : ICallHandler
    {
        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            var watch = new Stopwatch();
            Debug.WriteLine("Begin: {0}", new[] { input.MethodBase.Name });
           
            watch.Start();
            var result = getNext()(input, getNext);
            watch.Stop();
            
            Debug.WriteLine("End: {0} ({1} ms, {2} ticks)", input.MethodBase.Name, watch.ElapsedMilliseconds, watch.ElapsedTicks);
            return result;
        }

        public int Order { get; set; }
    }
}
