﻿using System.Collections.Generic;

namespace LiteMedia.BookStore.Lib.Model
{
    public class Book
    {
        public string Isbn { get; set; }

        public string Title { get; set; }

        public string Cover { get; set; }

        public virtual IList<Author> Authors
        {
            get { return new List<Author>(); }
        }
    }
}
