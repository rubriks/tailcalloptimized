Usage information
-----------------

http://mint.litemedia.se/togglchart/