﻿using System.Globalization;

namespace TogglChart.Lib
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class EnumerableExtensions
    {
        public static List<Tuple<int, double>>  GetAmountOfHoursPerWeek(this IEnumerable<Task> tasks, int weeks)
        {
            var data = new List<Tuple<int, double>>();

            var week = Week.Of(DateTime.Today);
            for (int i = 0; i < weeks; i++)
            {
                var amountOfWork = tasks.Where(t => t.Start > week.Start && t.Start < week.End)
                    .Sum(t => t.Duration);

                data.Add(new Tuple<int, double>(week.Number, Math.Round(amountOfWork / 3600d, 1)));
                week = week.Previous();
            }

            return data;
        }

        public static List<Tuple<int, double>> TrimBeginning(this IEnumerable<Tuple<int, double>> data)
        {
            var result = new List<Tuple<int, double>>();
            var trimming = true;
            foreach (var dataItem in data)
            {
                if (dataItem.Item2 == 0 && trimming)
                {
                    continue;
                }

                trimming = false;
                result.Add(dataItem);
            }

            return result;
        }
    }
}
