﻿namespace TogglChart.Lib
{
    using System;
    using System.Globalization;

    public class Week
    {
        public DateTime Start { get; private set; }

        public DateTime End { get; private set; }

        public Week Previous()
        {
            return new Week
            {
                Start = Start.AddDays(-7),
                End = End.AddDays(-7),
            };
        }

        public int Number
        {
            get
            {
                CultureInfo ciCurr = CultureInfo.CurrentCulture;
                int weekNum = ciCurr.Calendar.GetWeekOfYear(Start, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
                return weekNum;
            }
        }

        public static Week Of(DateTime date)
        {
            /* Starting monday */
            Func<DateTime, int> dayOfWeek = d => ((int)d.DayOfWeek + 6) % 7;

            return new Week
            {
                Start = date.AddDays(-1 * dayOfWeek(date)),
                End = date.AddDays(7 - dayOfWeek(date))
            };
        }
    }
}
