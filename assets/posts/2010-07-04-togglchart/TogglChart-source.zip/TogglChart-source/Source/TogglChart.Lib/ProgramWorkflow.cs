﻿namespace TogglChart.Lib
{
    using System.Linq;

    public class ProgramWorkflow
    {
        private Configuration configuration;

        public ProgramWorkflow(Configuration configuration)
        {
            this.configuration = configuration;
        }

        public void Run()
        {
            var client = new TogglClient();
            client.Authenticate(configuration.ApiToken);
            var tasks = client.GetTasks(configuration.Weeks);

            // Only filter on project, if project is set
            if (!string.IsNullOrEmpty(configuration.ProjectName))
            {
                tasks = tasks.Where(t => t.Project.Name == configuration.ProjectName)
                    .ToArray();
            }

            var data = tasks.GetAmountOfHoursPerWeek(configuration.Weeks);
            data = data.OrderBy(t => t.Item1).ToList();

            /* Remove empty weeks */
            if (configuration.Dynamic)
            {
                data = data.TrimBeginning();
            }

            var graph = Graph.Create(data);
            graph.SaveImage(
                configuration.ImageWidth,
                configuration.ImageHeight,
                configuration.ImageTitle,
                configuration.OutputFile,
                configuration.GetImageFormat());
        }
    }
}
