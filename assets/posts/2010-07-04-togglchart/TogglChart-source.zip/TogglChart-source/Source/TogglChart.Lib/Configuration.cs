﻿using System.Configuration;
using System.Drawing.Imaging;
using System.Text;

namespace TogglChart.Lib
{
    using System.Collections.Specialized;

    public class Configuration
    {
        private const string ApiTokenIdentifier = "apiToken";
        private const string ImageWidthIdentifier = "imageWidth";
        private const string ImageHeightIdentifier = "imageHeight";
        private const string ImageTitleIdentifier = "imageTitle";
        private const string OutputFileIdentifier = "outputFile";
        private const string ImageFormatIdentifier = "imageFormat";
        private const string WeeksIdentifier = "weeks";
        private const string ProjectIdentifier = "projectName";
        private const string DynamicIdentifier = "dynamic";

        private readonly NameValueCollection settings;

        static Configuration()
        {
            Instance = new Configuration(ConfigurationManager.AppSettings);
        }

        public Configuration(NameValueCollection settings)
        {
            this.settings = settings ?? new NameValueCollection();
        }

        public static Configuration Instance { get; set; }

        public string ApiToken
        {
            get { return settings[ApiTokenIdentifier]; }
            set { settings[ApiTokenIdentifier] = value; }
        }

        public int ImageWidth
        {
            get { return string.IsNullOrEmpty(settings[ImageWidthIdentifier]) ? 512 : int.Parse(settings[ImageWidthIdentifier]); }
            set { settings[ImageWidthIdentifier] = value.ToString(); }
        }

        public int ImageHeight
        {
            get { return string.IsNullOrEmpty(settings[ImageHeightIdentifier]) ? 384 : int.Parse(settings[ImageHeightIdentifier]); }
            set { settings[ImageHeightIdentifier] = value.ToString(); }
        }

        public string ImageTitle
        {
            get { return string.IsNullOrEmpty(settings[ImageTitleIdentifier]) ? "Time spent over " + Weeks + " weeks" : settings[ImageTitleIdentifier]; }
            set { settings[ImageTitleIdentifier] = value; }
        }

        public string OutputFile
        {
            get { return string.IsNullOrEmpty(settings[OutputFileIdentifier]) ? "togglchart.jpg" : settings[OutputFileIdentifier]; }
            set { settings[OutputFileIdentifier] = value; }
        }

        /// <summary>
        /// Valid values are Bmp, Gif, Jpeg, Png
        /// </summary>
        /// <value>The image format.</value>
        public string ImageFormat
        {
            get { return string.IsNullOrEmpty(settings[ImageFormatIdentifier]) ? "jpg" : settings[ImageFormatIdentifier]; }
            set { settings[ImageFormatIdentifier] = value; }
        }

        public int Weeks
        {
            get { return string.IsNullOrEmpty(settings[WeeksIdentifier]) ? 5 : int.Parse(settings[WeeksIdentifier]); }
            set { settings[WeeksIdentifier] = value.ToString(); }
        }

        public string ProjectName
        {
            get { return string.IsNullOrEmpty(settings[ProjectIdentifier]) ? null : settings[ProjectIdentifier]; }
            set { settings[ProjectIdentifier] = value; }
        }

        /// <summary>
        /// Gets or sets a value indicating whether empty weeks at the end should be removed from the chart.
        /// </summary>
        /// <value><c>true</c> if dynamic; otherwise, <c>false</c>.</value>
        public bool Dynamic
        {
            get { return string.IsNullOrEmpty(settings[DynamicIdentifier]) ? false : bool.Parse(settings[DynamicIdentifier]); }
            set { settings[DynamicIdentifier] = value.ToString(); }
        }

        public ImageFormat GetImageFormat()
        {
            switch (ImageFormat.ToLower())
            {
                case "jpeg":
                    return System.Drawing.Imaging.ImageFormat.Jpeg;

                case "jpg":
                    return System.Drawing.Imaging.ImageFormat.Jpeg;

                case "bmp":
                    return System.Drawing.Imaging.ImageFormat.Bmp;

                case "gif":
                    return System.Drawing.Imaging.ImageFormat.Gif;

                default:
                    return System.Drawing.Imaging.ImageFormat.Png;
            }
        }

        public override string ToString()
        {
            var sb = new StringBuilder();

            for (var i = 0; i < settings.Count; i++)
            {
                sb.AppendFormat("{0}: {1}\n", settings.GetKey(i), settings.GetValues(i)[0]);
            }

            return sb.ToString();
        }
    }
}
