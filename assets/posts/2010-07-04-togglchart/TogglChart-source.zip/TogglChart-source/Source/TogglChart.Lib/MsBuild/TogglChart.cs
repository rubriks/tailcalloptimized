﻿using TogglChart.Lib;

namespace TogglChart.MsBuild
{
    using System.Collections.Specialized;
    using Microsoft.Build.Framework;

    public class TogglChart : Microsoft.Build.Utilities.Task
    {
        [Required]
        public string ApiToken { get; set; }

        public int ImageWidth { get; set; }

        public int ImageHeight { get; set; }

        public string ImageTitle { get; set; }

        public string OutputFile { get; set; }

        public string ImageFormat { get; set; }

        public int Weeks { get; set; }

        public string ProjectName { get; set; }

        public bool Dynamic { get; set; }

        public override bool Execute()
        {
            if (string.IsNullOrEmpty(ApiToken))
            {
                Log.LogError("You must supply Toggl Api Token.\n{0}", "https://www.toggl.com/user/edit");
                return false;
            }

            var configuration = new Configuration(new NameValueCollection())
            {
                ApiToken = ApiToken,
                ImageWidth = ImageWidth,
                ImageHeight = ImageHeight,
                ImageTitle = ImageTitle,
                OutputFile = OutputFile,
                ImageFormat = ImageFormat,
                Weeks = Weeks,
                ProjectName = ProjectName,
                Dynamic = Dynamic
            };

            Log.LogMessageFromText(configuration.ToString(), MessageImportance.Normal);

            new ProgramWorkflow(configuration).Run();
            return true;
        }
    }
}
