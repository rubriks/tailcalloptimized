﻿using TogglChart.App_GlobalResources;

namespace TogglChart
{
    using System;
    using NDesk.Options;
    using Lib;

    public class Program
    {
        public static void Main(string[] args)
        {
            var configuration = Configuration.Instance;
            var outputHelp = false;

            var p = new OptionSet
            {
                { "apiToken=", CommandLineOptions.ApiToken, v => configuration.ApiToken = v },
                { "imageWidth=", CommandLineOptions.ImageWidth, v => configuration.ImageWidth = int.Parse(v) },
                { "imageHeight=", CommandLineOptions.ImageHeight, v => configuration.ImageHeight = int.Parse(v) },
                { "imageTitle=", CommandLineOptions.ImageTitle, v => configuration.ImageTitle = v },
                { "outputFile=", CommandLineOptions.OutputFile, v => configuration.OutputFile = v },
                { "imageFormat=", CommandLineOptions.ImageFormat, v => configuration.ImageFormat = v },
                { "weeks=", CommandLineOptions.Weeks, v  => configuration.Weeks = int.Parse(v) },
                { "projectName=", CommandLineOptions.ProjectName, v  => configuration.ProjectName = v },
                { "dynamic", CommandLineOptions.Dynamic, v  => configuration.Dynamic = true },
                { "help|h|?", CommandLineOptions.Help, v => outputHelp = true }
            };
            p.Parse(args);
            
            if (outputHelp)
            {
                p.WriteOptionDescriptions(Console.Out);
                Environment.Exit(0);
            }

            Console.WriteLine(configuration);
            new ProgramWorkflow(configuration).Run();
        }
    }
}
