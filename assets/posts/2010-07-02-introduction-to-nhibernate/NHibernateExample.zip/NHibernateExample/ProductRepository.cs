﻿namespace NHibernateExample
{
    using System.Collections.Generic;
    using Model;

    public class ProductRepository : RepositoryBase<Product>
    {
        public ProductRepository(SessionManager sessionManager)
            : base(sessionManager)
        {
        }

         public IEnumerable<Product> GetByCategory(Category category)
            {
                using (var session = SessionManager.OpenSession())
                {
                    return session.CreateQuery("FROM Product as product WHERE product.Category = :category")
                        .SetEntity("category", category)
                        .List<Product>();
                        
                }
            }
    }
}
