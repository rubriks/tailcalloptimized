﻿using System;
using NHibernateExample.Model;

namespace NHibernateExample
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var beverages = new CategoryRepository(SessionManager.Current).GetById(1);
            var product = new Product("Juice", 12d) { Category = beverages };

            var repository = new ProductRepository(SessionManager.Current);

            repository.Insert(product);
            product.Price = 15d;

            repository.Update(product);
            repository.Delete(product);

            foreach (var beverage in repository.GetByCategory(beverages))
            {
                Console.WriteLine("{0}, {1} {2:c}", beverage.ID, beverage.Name, beverage.Price);
            }

            Console.ReadLine();
        }
    }
}
