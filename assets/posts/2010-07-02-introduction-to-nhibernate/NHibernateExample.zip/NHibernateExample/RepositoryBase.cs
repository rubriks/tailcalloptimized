﻿using System.Diagnostics.CodeAnalysis;

namespace NHibernateExample
{
    public abstract class RepositoryBase<TEntity>
        where TEntity : class
    {
        protected SessionManager SessionManager;

        public RepositoryBase(SessionManager sessionManager)
        {
            SessionManager = sessionManager;
        }

        public TEntity GetById(int id)
        {
            using (var session = SessionManager.OpenSession())
            {
                return session.Get<TEntity>(id);
            }
        }

        public void Insert(TEntity entity)
        {
            using (var session = SessionManager.OpenSession())
            using (var transaction = session.BeginTransaction())
            {
                session.Save(entity);
                transaction.Commit();
            }
        }

        public void Update(TEntity entity)
        {
            using (var session = SessionManager.OpenSession())
            using (var transaction = session.BeginTransaction())
            {
                session.Update(entity);
                transaction.Commit();
            }
        }

        public void Delete(TEntity entity)
        {
            using (var session = SessionManager.OpenSession())
            using (var transaction = session.BeginTransaction())
            {
                session.Delete(entity);
                transaction.Commit();
            }
        }
    }
}