﻿using NHibernateExample.Model;

namespace NHibernateExample
{
    public class CategoryRepository : RepositoryBase<Category>
    {
        public CategoryRepository(SessionManager sessionManager)
            : base(sessionManager)
        {
        }
    }
}
