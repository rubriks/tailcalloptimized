﻿namespace NHibernateExample
{
    using NHibernate;
    using NHibernate.Cfg;

    public class SessionManager
    {
        private ISessionFactory globalSessionFactory;

        private static readonly object PadLock = new object();
        private static SessionManager instance;

        public static SessionManager Current
        {
            get
            {
                lock (PadLock)
                {
                    return instance ?? (instance = new SessionManager());
                }
            }
        }

        public ISession OpenSession()
        {
            if (globalSessionFactory == null)
            {
                globalSessionFactory = CreateSessionFactory();    
            }

            return globalSessionFactory.OpenSession();
        }

        private ISessionFactory CreateSessionFactory()
        {
            return new Configuration()
                .Configure()
                .AddAssembly(typeof(SessionManager).Assembly)
                .BuildSessionFactory();
        }

        private SessionManager()
        {
        }
    }
}
