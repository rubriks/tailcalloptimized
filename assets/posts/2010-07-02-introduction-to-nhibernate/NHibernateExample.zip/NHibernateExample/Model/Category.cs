﻿namespace NHibernateExample.Model
{
    public class Category
    {
        public virtual int ID { get; set; }

        public virtual string Name { get; set; }

        public virtual string Description { get; set; }
    }
}
