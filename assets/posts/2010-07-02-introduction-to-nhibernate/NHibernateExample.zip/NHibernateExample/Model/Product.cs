﻿namespace NHibernateExample.Model
{
    public class Product
    {
        public Product()
        {
        }

        public Product(string name, double price)
        {
            Name = name;
            Price = price;
        }

        public virtual int ID { get; set; }

        public virtual string Name { get; set; }

        public virtual double Price { get; set; }

        public virtual Category Category { get; set; }
    }
}
