﻿using System.Collections.Generic;

namespace LiteMedia.FileSync.Logic
{
    public interface IDirectory : IFileSystemItem
    {
        IEnumerable<IFile> Files { get; }

        IEnumerable<IDirectory> Directories { get; }

        IDirectory MakeDirectory(string name);

        bool Contains(string name);

        IFileSystemItem this[string name] { get; }

        void Remove(string name);
    }
}
