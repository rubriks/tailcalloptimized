﻿using System;

namespace LiteMedia.FileSync.Logic
{
    public interface IFileSystemItem
    {
        string Name { get; }

        string FullPath { get; }

        DateTime Modified { get; }
    }
}
