﻿namespace LiteMedia.FileSync.Logic
{
    using System;
    using System.Linq;

    public class FileSystemSynchronizer
    {
        private readonly IFileSystemFactory fsFactory;

        public FileSystemSynchronizer(IFileSystemFactory fsFactory)
        {
            this.fsFactory = fsFactory;
        }

        public void Synchronize(string sourcePath, string targetPath)
        {
            IDirectory sourceFolder = fsFactory.GetDirectory(sourcePath);
            IDirectory targetFolder = null;

            if (fsFactory.PathExists(targetPath))
            {
                targetFolder = fsFactory.GetDirectory(targetPath);
            }
            else
            {
                // Create target folder
                targetFolder = fsFactory.MakeDirectory(targetPath);
            }

            foreach (var file in sourceFolder.Files)
            {
                if (!targetFolder.Contains(file.Name))
                {
                    // Target does not contain file with same name
                    file.CopyTo(targetPath);
                }
                else
                {
                    var targetFile = targetFolder[file.Name];
                    if (file.Modified > targetFile.Modified)
                    {
                        // File in source is newer than file on target
                        file.CopyTo(targetPath, ConflictPolicy.Overwrite);
                    }
                }
            }

            // Delete files from target folder not present in source
            Func<IFile, string> fileNames = f => f.Name;

            var deleteFileNames = targetFolder.Files.Select(fileNames)
                .Except(sourceFolder.Files.Select(fileNames))
                .ToList();

            foreach (var fileName in deleteFileNames)
            {
                targetFolder.Remove(fileName);
            }
                
            // Recurse into subdirectories
            foreach (var sourceSubDirectory in sourceFolder.Directories)
            {
                var targetSubDirectory = targetFolder.MakeDirectory(sourceSubDirectory.Name);
                this.Synchronize(sourceSubDirectory.FullPath, targetSubDirectory.FullPath);
            }
        }
    }
}
