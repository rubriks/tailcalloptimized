﻿namespace LiteMedia.FileSync.Logic
{
    public interface IFile : IFileSystemItem
    {
        void CopyTo(string targetPath, ConflictPolicy conflictPolicy = ConflictPolicy.Exception);
    }
}
