﻿namespace LiteMedia.FileSync.Logic
{
    public enum ConflictPolicy
    {
        // Ignore that there is a conflict
        Ignore = 0,

        // Overwrite the conflicting file/directory
        Overwrite = 1,

        // Throw an exception on conflict
        Exception = 2
    }
}
