﻿namespace LiteMedia.FileSync.Logic.Impl
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    public class FileSystemDirectory : IDirectory
    {
        private readonly DirectoryInfo di;

        public FileSystemDirectory(DirectoryInfo di)
        {
            this.di = di;
        }

        public string Name
        {
            get { return di.Name; }
        }

        public DateTime Modified
        {
            get { return di.LastWriteTime; }
        }

        public IEnumerable<IFile> Files
        {
            get
            {
                return di.GetFiles().Select(fileInfo => new FileSystemFile(fileInfo));
            }
        }

        public IEnumerable<IDirectory> Directories
        {
            get
            {
                return di.GetDirectories().Select(directoryInfo => new FileSystemDirectory(directoryInfo));
            }
        }

        public string FullPath
        {
            get
            {
                return di.FullName;
            }
        }

        public IFileSystemItem this[string name]
        {
            get
            {
                var file = di.EnumerateFiles().FirstOrDefault(CaseInsensitiveCompare(name));
                if (file != null)
                {
                    return new FileSystemFile(file);
                }

                var directory = di.EnumerateDirectories().FirstOrDefault(CaseInsensitiveCompare(name));
                if (directory != null)
                {
                    return new FileSystemDirectory((DirectoryInfo)directory);
                }

                return null;
            }
        }
        
        public IDirectory MakeDirectory(string name)
        {
            return new FileSystemDirectory(this.di.CreateSubdirectory(name));
        }

        public bool Contains(string name)
        {
            return this.di.EnumerateFileSystemInfos().Any(CaseInsensitiveCompare(name));
        }

        public void Remove(string name)
        {
            var fisi = di.EnumerateFileSystemInfos().First(CaseInsensitiveCompare(name));
            fisi.Delete();
        }

        private static Func<FileSystemInfo, bool> CaseInsensitiveCompare(string s)
        {
            return fi => fi.Name.Equals(s, StringComparison.InvariantCultureIgnoreCase);
        }
    }
}
