﻿using System;

namespace LiteMedia.FileSync.Logic.Impl
{
    using System.IO;

    public class FileSystemFile : IFile
    {
        private readonly FileSystemInfo fi;

        public FileSystemFile(FileSystemInfo fi)
        {
            this.fi = fi;
        }

        public string Name
        {
            get
            {
                return fi.Name;
            }
        }

        public string FullPath
        {
            get
            {
                return fi.FullName;
            }
        }

        public DateTime Modified
        {
            get
            {
                return fi.LastWriteTime;
            }
        }

        public void CopyTo(string targetPath, ConflictPolicy conflictPolicy)
        {
            var destFileName = Path.Combine(targetPath, Name);
            if (File.Exists(destFileName))
            {
                switch (conflictPolicy)
                {
                    case ConflictPolicy.Overwrite:
                        break;
                    case ConflictPolicy.Exception:
                        throw new Exception("There's already a file at " + destFileName + " and overwriting is not allowed");
                    default:
                        return;

                }
            }

            File.Copy(FullPath, destFileName, true);
        }
    }
}
