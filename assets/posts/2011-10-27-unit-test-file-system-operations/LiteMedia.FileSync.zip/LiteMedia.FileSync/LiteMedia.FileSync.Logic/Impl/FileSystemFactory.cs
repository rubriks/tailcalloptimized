﻿namespace LiteMedia.FileSync.Logic.Impl
{
    using System.IO;
    using System;

    public class FileSystemFactory : IFileSystemFactory
    {
        public bool PathExists(string targetPath)
        {
            return Directory.Exists(targetPath);
        }

        public IDirectory MakeDirectory(string targetPath)
        {
            return new FileSystemDirectory(Directory.CreateDirectory(targetPath));
        }

        public IDirectory GetDirectory(string sourcePath)
        {
            return new FileSystemDirectory(new DirectoryInfo(sourcePath));
        }
    }
}
