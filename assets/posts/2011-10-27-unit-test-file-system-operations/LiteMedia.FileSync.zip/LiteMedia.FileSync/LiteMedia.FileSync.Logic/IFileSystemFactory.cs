﻿namespace LiteMedia.FileSync.Logic
{
    public interface IFileSystemFactory
    {
        bool PathExists(string targetPath);

        IDirectory MakeDirectory(string targetPath);

        IDirectory GetDirectory(string sourcePath);
    }
}
