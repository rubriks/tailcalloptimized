﻿namespace LiteMedia.FileSync.Tests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    using LiteMedia.FileSync.Logic;
    using Xunit;

    public class FileSystemSynchronizerSpecification
    {
        private const string SourcePath = @"C:\FolderA";
        private const string TargetPath = @"C:\FolderB";

        [Fact]
        public void ShouldCreateTargetFolderIfDoesNotExist()
        {
            const string UnknownTargetPath = @"C:\FolderC";

            /* Setup */
            var factory = new VirtualFileSystemFactory();
            this.CreateFileSystem(factory);
            var sut = new FileSystemSynchronizer(factory);

            /* Test */
            sut.Synchronize(SourcePath, UnknownTargetPath);

            /* Assert */
            Assert.True(factory.PathExists(UnknownTargetPath), "Target path should be created if it does not exist");
        }

        [Fact]
        public void ShouldCopyAnyFilesFromSourceFolderToTargetFolder()
        {
            /* Setup */
            var factory = new VirtualFileSystemFactory();
            this.CreateFileSystem(factory);
            var sut = new FileSystemSynchronizer(factory);

            // Create files in source folder
            var sourceFolder = factory.GetDirectory(SourcePath) as VirtualFolder;
            sourceFolder.Add(new VirtualFile("first.txt", factory));
            sourceFolder.Add(new VirtualFile("second.txt", factory));

            /* Test */
            sut.Synchronize(SourcePath, TargetPath);

            /* Assert */
            var targetFolder = factory.GetDirectory(TargetPath);
            foreach (var file in sourceFolder.Files)
            {
                Assert.Contains(file, targetFolder.Files);
            }
        }

        [Fact]
        public void ShouldCopyAnyDirectoriesFromSourceFolderToTargetFolder()
        {
            /* Setup */
            var factory = new VirtualFileSystemFactory();
            this.CreateFileSystem(factory);
            var sut = new FileSystemSynchronizer(factory);

            // Create two folders in source directory
            var sourceFolder = factory.GetDirectory(SourcePath);
            sourceFolder.MakeDirectory("SubFolder1");
            sourceFolder.MakeDirectory("SubFolder2");

            /* Test */
            sut.Synchronize(SourcePath, TargetPath);

            /* Assert */
            var targetFolder = factory.GetDirectory(TargetPath);
            foreach (var folder in sourceFolder.Directories)
            {
                Assert.Contains(folder, targetFolder.Directories);
            }
        }

        [Fact]
        public void ShouldCopyFilesAndFoldersRecursivlyFromSourceToTargetFolder()
        {
            /* Setup */
            var factory = new VirtualFileSystemFactory();
            this.CreateFileSystem(factory);
            var sut = new FileSystemSynchronizer(factory);

            // Create file structure
            // - FolderA
            // - FolderA/FolderC
            // - FolderA/FolderC/first.txt
            var sourceFolder = factory.GetDirectory(SourcePath);
            var folderC = sourceFolder.MakeDirectory("folderc") as VirtualFolder;
            var file = new VirtualFile("first.txt", factory);
            folderC.Add(file);
            
            /* Test */
            sut.Synchronize(SourcePath, TargetPath);

            /* Assert */
            var targetFolder = factory.GetDirectory(TargetPath);
            var targetSubFolder = targetFolder.Directories.First();
            Assert.Contains(file, targetSubFolder.Files);
        }

        [Fact]
        public void ShouldNotCopySourceFileIfSameFileExistInTargetFolder()
        {
            /* Setup */
            var factory = new VirtualFileSystemFactory();
            this.CreateFileSystem(factory);
            var sut = new FileSystemSynchronizer(factory);

            // File first.txt exists at both source and target, but target is newer
            var file1 = new VirtualFile("first.txt", factory) { Modified = DateTime.Now };
            var file2 = new VirtualFile("first.txt", factory) { Modified = DateTime.Now.AddMinutes(1) };
            var sourceFolder = factory.GetDirectory(SourcePath) as VirtualFolder;
            var targetFolder = factory.GetDirectory(TargetPath) as VirtualFolder;
            sourceFolder.Add(file1);
            targetFolder.Add(file2);

            /* Test */
            sut.Synchronize(SourcePath, TargetPath);

            /* Assert */
            Assert.NotEqual(sourceFolder.Files.First().Modified, targetFolder.Files.First().Modified);
        }

        [Fact]
        public void ShouldCopySourceFileIfNewerThanFileInTargetFolder()
        {
            /* Setup */
            var factory = new VirtualFileSystemFactory();
            this.CreateFileSystem(factory);
            var sut = new FileSystemSynchronizer(factory);

            // File first.txt exists at both source and target, but source is newer
            var file1 = new VirtualFile("first.txt", factory) { Modified = DateTime.Now.AddMinutes(1) };
            var file2 = new VirtualFile("first.txt", factory) { Modified = DateTime.Now };
            var sourceFolder = factory.GetDirectory(SourcePath) as VirtualFolder;
            var targetFolder = factory.GetDirectory(TargetPath) as VirtualFolder;
            sourceFolder.Add(file1);
            targetFolder.Add(file2);

            /* Test */
            sut.Synchronize(SourcePath, TargetPath);

            /* Assert */
            Assert.Equal(sourceFolder.Files.First().Modified, targetFolder.Files.First().Modified);
        }

        [Fact]
        public void ShouldRemoveFilesFromTargetFolderNotPresentInSourceFolder()
        {
            /* Setup */
            var factory = new VirtualFileSystemFactory();
            this.CreateFileSystem(factory);
            var sut = new FileSystemSynchronizer(factory);

            // Add a file to target that should be removed
            var targetFolder = factory.GetDirectory(TargetPath) as VirtualFolder;
            targetFolder.Add(new VirtualFile("first.txt", factory));

            /* Test */
            sut.Synchronize(SourcePath, TargetPath);

            /* Assert */
            Assert.Empty(targetFolder.Files);
        }

        private void CreateFileSystem(IFileSystemFactory fileSystem)
        {
            fileSystem.MakeDirectory(SourcePath);
            fileSystem.MakeDirectory(TargetPath);
        }
    }
}
