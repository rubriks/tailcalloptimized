﻿namespace LiteMedia.FileSync.Tests
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using LiteMedia.FileSync.Logic;

    public class VirtualFileSystemFactory : IFileSystemFactory
    {
        private readonly IDictionary<string, IDirectory> fileSystem;

        public VirtualFileSystemFactory()
        {
            this.fileSystem = new Dictionary<string, IDirectory>();
        }

        public bool PathExists(string targetPath)
        {
            return fileSystem.ContainsKey(targetPath);
        }

        public IDirectory MakeDirectory(string targetPath)
        {
            var directory = new VirtualFolder(targetPath, this); 
            fileSystem.Add(targetPath, directory);
            return directory;
        }

        public IDirectory GetDirectory(string sourcePath)
        {
            if (!this.PathExists(sourcePath))
            {
                throw new DirectoryNotFoundException("Folder was not registered in VirtualFileSystemFactory: " + sourcePath);
            }

            return fileSystem[sourcePath];
        }

        /// <summary>
        /// Copies the specified file.
        /// </summary>
        public void Copy(IFile file, string targetPath, ConflictPolicy conflictPolicy)
        {
            var targetDirectory = this.GetDirectory(targetPath) as VirtualFolder;

            if (targetDirectory.Contains(file.Name))
            {
                switch (conflictPolicy) 
                {
                    case ConflictPolicy.Overwrite:
                        targetDirectory.Remove(file.Name);
                        break;

                    case ConflictPolicy.Exception:
                        throw new Exception("The file " + file.Name + " conflicts with a file at target path " + targetPath);

                    default:
                        return;
                }
            }
            
            targetDirectory.Add(file);
        }
    }

    public class VirtualFile : IFile
    {
        private readonly VirtualFileSystemFactory fsFactory;

        public VirtualFile(string name, VirtualFileSystemFactory fsFactory)
        {
            this.fsFactory = fsFactory;
            Name = name;
        }

        public string Name { get; set; }

        public string FullPath
        {
            get
            {
                throw new NotImplementedException("Not used in FileSystemSynchronizer but needed by the implementation of FileSystemFactory.Copy");
            }
        }

        public DateTime Modified { get; set; }

        public void CopyTo(string targetPath, ConflictPolicy conflictPolicy)
        {
            fsFactory.Copy(this, targetPath, conflictPolicy);
        }

        public override string ToString()
        {
            return Name;
        }
    }

    public class VirtualFolder : IDirectory, IEnumerable<IFileSystemItem>
    {
        private readonly string fullPath;
        private readonly VirtualFileSystemFactory fsFactory;
        private readonly IList<IFileSystemItem> items;

        public VirtualFolder(string fullPath, VirtualFileSystemFactory fsFactory)
        {
            this.fullPath = fullPath;
            this.fsFactory = fsFactory;
            items = new List<IFileSystemItem>();
        }

        public IEnumerable<IFile> Files
        {
            get { return items.Where(f => f is IFile).Cast<IFile>(); }
        }

        public IEnumerable<IDirectory> Directories
        {
            get { return items.Where(f => f is IDirectory).Cast<IDirectory>(); }
        }

        public string Name
        {
            get { return this.fullPath.Substring(fullPath.LastIndexOf("\\") + 1); }
        }

        public DateTime Modified { get; set; }

        public string FullPath
        {
            get { return this.fullPath; }
        }

        public void Add(IFileSystemItem item)
        {
            if (Contains(item.Name))
            {
                throw new Exception("Cannot add item when another item with the same name alread exists");
            }

            items.Add(item);
        }

        public IDirectory MakeDirectory(string name)
        {
            var directory = fsFactory.MakeDirectory(FullPath + @"\" + name);
            this.Add(directory);
            return directory;
        }

        public bool Contains(string itemName)
        {
            return items.Any(i => i.Name.Equals(itemName, StringComparison.InvariantCulture));
        }

        public IFileSystemItem this[string name]
        {
            get
            {
                return items.FirstOrDefault(i => i.Name.Equals(name, StringComparison.InvariantCulture));
            }
        }

        public void Remove(string name)
        {
            items.Remove(this[name]);
        }

        public IEnumerator<IFileSystemItem> GetEnumerator()
        {
            return items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return items.GetEnumerator();
        }
    }
}
