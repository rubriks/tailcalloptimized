﻿namespace LiteMedia.FileSync
{
    using LiteMedia.FileSync.Logic;
    using LiteMedia.FileSync.Logic.Impl;

    class Program
    {
        static void Main(string[] args)
        {
            new FileSystemSynchronizer(new FileSystemFactory())
                .Synchronize(args[0], args[1]);
        }
    }
}
