﻿namespace TogglChart
{
    using System;
    using System.Collections.Generic;
    using System.Drawing;
    using System.Drawing.Imaging;
    using System.Linq;
    using ZedGraph;

    public class Graph
    {
        private readonly List<Tuple<int, double>> data;

        public Graph()
        {
            data = new List<Tuple<int, double>>();
        }

        public void Add(Tuple<int, double> item)
        {
            data.Add(item);
        }

        public static Graph Create(IEnumerable<Tuple<int, double>> values)
        {
            var graph = new Graph();
            foreach (var value in values)
            {
                graph.Add(value);
            }

            return graph;
        }

        public void SaveImage(int width, int height, string title)
        {
            GraphPane myPane = new GraphPane(new RectangleF(0, 0, width, height), title, "Week", "Hours");
            myPane.IsBoundedRanges = true;

            var ppl = new PointPairList();
            foreach (var week in data)
            {
                ppl.Add(week.Item1, week.Item2);
            }

            // Hide the legend
            myPane.Legend.IsVisible = false;
            var foreground = Color.FromArgb(255, 55, 108, 153);

            myPane.XAxis.AxisGap = 1f;
            myPane.XAxis.Type = AxisType.Text;
            myPane.XAxis.Scale.TextLabels = data.Select(t => "Week " + t.Item1).ToArray();

            myPane.YAxis.Scale.Min = 0;
            myPane.YAxis.Scale.MinorStep = 1;
            myPane.YAxis.MinorTic.Color = Color.Transparent;

            myPane.Border.IsVisible = false;

            LineItem curve = myPane.AddCurve("Hours of effort", ppl, foreground, SymbolType.Circle);
            curve.Line.Width = 2.0F;
            curve.Line.IsAntiAlias = true;
            curve.Symbol.Fill = new Fill(Color.White);
            curve.Symbol.Size = 7;

            // Leave some extra space on top for the labels to fit within the chart rect
            myPane.YAxis.Scale.MaxGrace = 0.1;

            myPane.Chart.Fill = new Fill(Color.White, Color.FromArgb(220, 220, 255), 45);
            myPane.Fill = new Fill(Color.White);

            Bitmap bm = new Bitmap(1, 1);
            using (Graphics g = Graphics.FromImage(bm))
                myPane.AxisChange(g);

            myPane.GetImage().Save(@"togglgraph.png", ImageFormat.Png);
        }
    }
}
