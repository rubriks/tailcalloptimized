﻿using System.Globalization;

namespace TogglChart
{
    using System;
    using System.Collections.Generic;
    using System.Linq;

    public static class EnumerableExtensions
    {
        private const int MaxAmountOfWeeks = 5;

        public static List<Tuple<int, double>>  GetAmountOfHoursPerWeek(this IEnumerable<Task> tasks)
        {
            var data = new List<Tuple<int, double>>();

            var week = Week.Of(DateTime.Today);
            for (int i = 0; i < MaxAmountOfWeeks; i++)
            {
                var amountOfWork = tasks.Where(t => t.Start > week.Start && t.Start < week.End)
                    .Sum(t => t.Duration);

                /* Stop if there's an empty week */
                //if (amountOfWork == 0)
                //{
                //    break;
                //}

                data.Add(new Tuple<int, double>(week.Number, Math.Round(amountOfWork / 3600d, 1)));
                week = week.Previous();
            }

            return data;
        }

        private class Week
        {
            public DateTime Start { get; private set; }

            public DateTime End { get; private set; }

            public Week Previous()
            {
                return new Week
                {
                    Start = Start.AddDays(-7),
                    End = End.AddDays(-7),
                };
            }
            
            public int Number
            {
                get 
                {
                    CultureInfo ciCurr = CultureInfo.CurrentCulture;
                    int weekNum = ciCurr.Calendar.GetWeekOfYear(Start, CalendarWeekRule.FirstFourDayWeek, DayOfWeek.Monday);
                    return weekNum;
                }
            }

            public static Week Of(DateTime date)
            {
                /* Starting monday */
                Func<DateTime, int> dayOfWeek = d => ((int) d.DayOfWeek - 1) % 7;

                return new Week
                {
                    Start = date.AddDays(-1 * dayOfWeek(date)),
                    End = date.AddDays(7 - dayOfWeek(date))
                };
            }
        }
    }
}
