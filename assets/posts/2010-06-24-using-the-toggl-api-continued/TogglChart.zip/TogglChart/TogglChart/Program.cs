﻿using System.Configuration;
using System.Linq;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace TogglChart
{
    using System;
    using System.IO;
    using System.Net;
    using System.Text;

    public class Program
    {
        public static void Main(string[] args)
        {
            var configuration = Configuration.Instance;

            var client = new TogglClient();
            client.Authenticate(configuration.ApiToken);
            var tasks = client.GetTasks();
            
            var data = tasks.GetAmountOfHoursPerWeek();
            data.Reverse();

            var graph = Graph.Create(data);
            graph.SaveImage(
                configuration.ImageWidth,
                configuration.ImageHeight,
                configuration.ImageTitle);
        }
    }
}
