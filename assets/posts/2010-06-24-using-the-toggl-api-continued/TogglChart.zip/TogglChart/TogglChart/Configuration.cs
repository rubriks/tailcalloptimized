﻿using System.Configuration;

namespace TogglChart
{
    using System.Collections.Specialized;

    public class Configuration
    {
        private const string ApiTokenIdentifier = "apiToken";
        private const string ImageWidthIdentifier = "imageWidth";
        private const string ImageHeightIdentifier = "imageHeight";
        private const string ImageTitleIdentifier = "imageTitle";

        private readonly NameValueCollection appSettings;

        static Configuration()
        {
            Instance = new Configuration(ConfigurationManager.AppSettings);
        }

        public Configuration(NameValueCollection appSettings)
        {
            this.appSettings = appSettings;
        }

        public static Configuration Instance { get; set; }

        public string ApiToken
        {
            get { return appSettings[ApiTokenIdentifier]; }
        }

        public int ImageWidth
        {
            get { return int.Parse(appSettings[ImageWidthIdentifier]); }
        }

        public int ImageHeight
        {
            get { return int.Parse(appSettings[ImageHeightIdentifier]); }
        }

        public string ImageTitle
        {
            get { return appSettings[ImageTitleIdentifier]; }
        }
    }
}
