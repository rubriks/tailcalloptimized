﻿using System;

namespace TogglChart
{
    using System.IO;
    using System.Net;
    using System.Text;
    using Newtonsoft.Json;

    public class TogglClient
    {
        private const string TogglAuthUrl = "http://www.toggl.com/api/v1/sessions.json";
        private const string TogglTasksUrl = "https://www.toggl.com/api/v1/tasks.json";

        private const string Password = "api_token";

        private readonly CookieContainer authTokenContainer;

        public TogglClient()
        {
            authTokenContainer = new CookieContainer();
        }

        public void Authenticate(string apiToken)
        {
            var request = (HttpWebRequest) WebRequest.Create(TogglAuthUrl);

            request.Credentials = CredentialCache.DefaultCredentials;
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.CookieContainer = authTokenContainer;

            string value = Password + "=" + apiToken;
            request.ContentLength = value.Length;
            using (var writer = new StreamWriter(request.GetRequestStream(), Encoding.ASCII))
            {
                writer.Write(value);
            }

            var response = (HttpWebResponse)request.GetResponse();
            response.Close();
        }

        public Task[] GetTasks()
        {
            var request = (HttpWebRequest) WebRequest.Create(TogglTasksUrl);
            request.CookieContainer = authTokenContainer;

            var response = (HttpWebResponse)request.GetResponse();
            
            try
            {                
                using (var reader = new StreamReader(response.GetResponseStream(), Encoding.UTF8))
                {
                    var json = reader.ReadToEnd();
                    return JsonConvert.DeserializeObject<Task[]>(json);
                }
            }
            finally
            {

                response.Close();
            }
        }
    }
}
