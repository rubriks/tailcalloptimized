﻿using System.Data.Common;

namespace AopExample
{
    public class CustomerDataAccess : IDataAccess<Customer>
    {
        private readonly IDataFactory dataFactory;

        public CustomerDataAccess(IDataFactory dataFactory)
        {
            this.dataFactory = dataFactory;
        }

        public Customer GetById(int id)
        {
            Customer result;

            using (var connection = dataFactory.OpenConnection())
            {
                var command = connection.CreateCommand();
                command.CommandText = "SELECT * FROM Customer WHERE id=" + id; // Beware of SQL injection

                var reader = command.ExecuteReader();
                result = reader.GetCustomer(id);
            }

            return result;
        }
    }

    public static class DbDataReaderExtensions
    {
        public static Customer GetCustomer(this DbDataReader reader, int id)
        {
            return new Customer { Id = id, Name = "John Doe" };
        }
    }
}
