﻿namespace AopExample
{
    using Microsoft.Practices.Unity.InterceptionExtension;

    public class LogCallHandler : ICallHandler
    {
        public int Order { get; set; }

        public IMethodReturn Invoke(IMethodInvocation input, GetNextHandlerDelegate getNext)
        {
            string className = input.MethodBase.DeclaringType.Name;
            string methodName = input.MethodBase.Name;
            string generic = input.MethodBase.DeclaringType.IsGenericType ? string.Format("<{0}>", input.MethodBase.DeclaringType.GetGenericArguments().ToStringList()) : string.Empty;
            string arguments = input.Arguments.ToStringList();

            /* CustomerDataAccess.GetById(123) */
            string preMethodMessage = string.Format("{0}{1}.{2}({3})", className, generic, methodName, arguments);
            System.Diagnostics.Debug.WriteLine(preMethodMessage);

            /* Call the method that was intercepted */
            IMethodReturn msg = getNext()(input, getNext);

            /* CustomerDataAccess.GetById() -> Customer { Id = 123, Name = John Doe } */
            string postMethodMessage = string.Format("{0}{1}.{2}() -> {3}", className, generic, methodName, msg.ReturnValue);
            System.Diagnostics.Debug.WriteLine(postMethodMessage);

            return msg;
        }
    }
}
