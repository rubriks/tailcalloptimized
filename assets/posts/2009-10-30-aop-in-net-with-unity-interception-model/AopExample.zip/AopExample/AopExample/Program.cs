﻿namespace AopExample
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var container = new Container();
            container.Configure();

            var dataAccess = container.Resolve<IDataAccess<Customer>>();
            dataAccess.GetById(1);
        }
    }
}
