﻿namespace AopExample
{
    using System.Data.Common;

    public interface IDataFactory
    {
        DbConnection OpenConnection();
    }
}
