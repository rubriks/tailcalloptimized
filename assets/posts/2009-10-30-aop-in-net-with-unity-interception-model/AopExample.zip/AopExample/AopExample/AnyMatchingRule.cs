﻿namespace AopExample
{
    using System.Reflection;
    using Microsoft.Practices.Unity.InterceptionExtension;

    public class AnyMatchingRule : IMatchingRule
    {
        public bool Matches(MethodBase member)
        {
            return true;
        }
    }
}
