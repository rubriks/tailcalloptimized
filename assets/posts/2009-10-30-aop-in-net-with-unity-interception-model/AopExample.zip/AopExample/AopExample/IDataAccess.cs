﻿namespace AopExample
{
    public interface IDataAccess<T>
        where T : new()
    {
        T GetById(int id);
    }
}
