﻿namespace AopExample
{
    using Microsoft.Practices.Unity;
    using Microsoft.Practices.Unity.InterceptionExtension;

    public class Container : UnityContainer
    {
        private const string LogPolicy = "LogPolicy";
        private const string AnyMatchingRule = "AnyMatchingRule";
        private const string LogCallHandler = "LogCallHandler";
        

        public void Configure()
        {
            /* Register types into the container */
            RegisterType<IDataFactory, StubDataFactory>();
            RegisterType<IDataAccess<Customer>, CustomerDataAccess>();

            /* Register our matching rule and call handler */
            RegisterType<IMatchingRule, AnyMatchingRule>(AnyMatchingRule);
            RegisterType<ICallHandler, LogCallHandler>(LogCallHandler);

            /* Create a new policy and reference the matching rule and call handler by name */
            AddNewExtension<Interception>();
            Configure<Interception>().AddPolicy(LogPolicy)
                .AddMatchingRule(AnyMatchingRule)
                .AddCallHandler(LogCallHandler);

            /* Make IDataAccess interface elegible for interception */
            Configure<Interception>().SetInterceptorFor(typeof(IDataAccess<>), new TransparentProxyInterceptor());
        }
    }
}
