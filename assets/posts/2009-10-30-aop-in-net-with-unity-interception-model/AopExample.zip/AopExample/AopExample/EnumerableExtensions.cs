﻿namespace AopExample
{
    using System.Collections;
    using System.Text;

    public static class EnumerableExtensions
    {
        public static string ToStringList(this IEnumerable list)
        {
            StringBuilder sb = new StringBuilder();

            foreach (var item in list)
            {
                sb.AppendFormat("{0}, ", item);
            }

            sb.Remove(sb.Length - 2, 2);
            return sb.ToString();
        }
    }
}
