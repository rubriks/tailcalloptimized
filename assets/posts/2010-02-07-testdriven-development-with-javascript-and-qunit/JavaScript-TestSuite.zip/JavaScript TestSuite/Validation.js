﻿var heartbeat = {}

/* Initialize the validation by setting the validation on each validating field */
heartbeat.initialize = function () {
    $('div.field').each(heartbeat.addValidation);
}

/* Add validation to a specific element by determine validation on class */
heartbeat.addValidation = function (index, element) {
    var el = $(element);
    if (el.data('initialized') != undefined) {
        console.warn('initialized() was called more than once on element: ' + element +  '[' + index + ']');
        return;
    }

    if (el.data('isValid') == undefined) {
        el.data('isValid', true);
        el.data('validations', new Array());
    }

    if (el.hasClass('required')) {
        el.data('validations').push(heartbeat.requiredValidation);
    }

    /* Add validation to element blur */
    heartbeat.getInputField(el).blur(heartbeat.validate);
    el.data('initialized', true);
}

/* Find first input field from under element */
heartbeat.getInputField = function (element) {
    return $(element).find('input');
}

/* Run all validations on the given field */
heartbeat.validate = function () {
    var validationElement = $(this).parent();
    $.each(validationElement.data('validations'), function (index, validation) { validation(validationElement, heartbeat.validated); });
}

/* Will set the appropriate fields depending on validation result */
heartbeat.validated = function (element, isValid, validationMessage) {
    var previousStatus = element.data('isValid');

    if (previousStatus == isValid) {
        return;
    }

    if (isValid) {
        element.find('span.field-validation-error').remove();
    }
    else {
        element.append('<span class=\"field-validation-error\">' + validationMessage + '</span>');
    }

    element.data('isValid', isValid);
}

heartbeat.requiredValidation = function (element, validated) {
    var inputField = heartbeat.getInputField(element);
    var isValid = inputField.val() != '';

    validated(element, isValid, 'This field is required');
}
