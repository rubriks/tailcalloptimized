﻿namespace LiteMedia.Alive.Web.Test
{
    using System;
    using System.Diagnostics;

    public partial class Index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void IncreaseCounter(object sender, EventArgs e)
        {
            using (var counter = new PerformanceCounter("Test Category", "Test Increment", readOnly: false))
            {
                counter.Increment();
            }
        }
    }
}